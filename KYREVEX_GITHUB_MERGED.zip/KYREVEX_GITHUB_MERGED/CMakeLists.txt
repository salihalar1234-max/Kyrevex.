cmake_minimum_required(VERSION 3.20)
project(KYREVEX_MERGED LANGUAGES CXX)
enable_testing()
add_subdirectory(cpp)
