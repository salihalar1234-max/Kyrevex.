#ifdef __ANDROID__

#include "platform/android/AAudioBackend.hpp"
#include "game/AudioEngine.hpp"

#include <aaudio/AAudio.h>

namespace kyrevex::audio {

AAudioBackend::~AAudioBackend() { stop(); }

bool AAudioBackend::start(AudioEngine& engine, std::int32_t requestedSampleRate) noexcept {
    stop();
    AAudioStreamBuilder* builder = nullptr;
    aaudio_result_t result = AAudio_createStreamBuilder(&builder);
    if (result != AAUDIO_OK || builder == nullptr) {
        lastError_.store(result, std::memory_order_relaxed);
        return false;
    }

    AAudioStreamBuilder_setDirection(builder, AAUDIO_DIRECTION_OUTPUT);
    AAudioStreamBuilder_setFormat(builder, AAUDIO_FORMAT_PCM_FLOAT);
    AAudioStreamBuilder_setChannelCount(builder, 2);
    AAudioStreamBuilder_setPerformanceMode(builder, AAUDIO_PERFORMANCE_MODE_LOW_LATENCY);
    AAudioStreamBuilder_setSharingMode(builder, AAUDIO_SHARING_MODE_SHARED);
    AAudioStreamBuilder_setUsage(builder, AAUDIO_USAGE_GAME);
    AAudioStreamBuilder_setContentType(builder, AAUDIO_CONTENT_TYPE_MUSIC);
    if (requestedSampleRate >= 8000 && requestedSampleRate <= 192000) {
        AAudioStreamBuilder_setSampleRate(builder, requestedSampleRate);
    }
    AAudioStreamBuilder_setDataCallback(builder, &AAudioBackend::dataCallback, this);
    AAudioStreamBuilder_setErrorCallback(builder, &AAudioBackend::errorCallback, this);

    engine_ = &engine;
    disconnected_.store(false, std::memory_order_relaxed);
    lastError_.store(0, std::memory_order_relaxed);
    result = AAudioStreamBuilder_openStream(builder, &stream_);
    AAudioStreamBuilder_delete(builder);
    if (result != AAUDIO_OK || stream_ == nullptr) {
        engine_ = nullptr;
        lastError_.store(result, std::memory_order_relaxed);
        return false;
    }

    const auto rate = AAudioStream_getSampleRate(stream_);
    const auto channels = AAudioStream_getChannelCount(stream_);
    if (rate < 8000 || rate > 192000 || channels != 2) {
        lastError_.store(AAUDIO_ERROR_INVALID_FORMAT, std::memory_order_relaxed);
        stop();
        return false;
    }
    engine.setOutputSampleRate(static_cast<std::uint32_t>(rate));

    result = AAudioStream_requestStart(stream_);
    if (result != AAUDIO_OK) {
        lastError_.store(result, std::memory_order_relaxed);
        stop();
        return false;
    }
    return true;
}

void AAudioBackend::stop() noexcept {
    if (stream_ != nullptr) {
        const auto state = AAudioStream_getState(stream_);
        if (state == AAUDIO_STREAM_STATE_STARTED || state == AAUDIO_STREAM_STATE_STARTING ||
            state == AAUDIO_STREAM_STATE_PAUSING || state == AAUDIO_STREAM_STATE_PAUSED) {
            (void)AAudioStream_requestStop(stream_);
        }
        (void)AAudioStream_close(stream_);
        stream_ = nullptr;
    }
    engine_ = nullptr;
}

AAudioBackendStatus AAudioBackend::status() const noexcept {
    AAudioBackendStatus value{};
    value.open = stream_ != nullptr;
    value.running = value.open && AAudioStream_getState(stream_) == AAUDIO_STREAM_STATE_STARTED;
    value.disconnected = disconnected_.load(std::memory_order_relaxed);
    value.lastError = lastError_.load(std::memory_order_relaxed);
    if (stream_ != nullptr) {
        value.sampleRate = AAudioStream_getSampleRate(stream_);
        value.channelCount = AAudioStream_getChannelCount(stream_);
    }
    return value;
}

std::int32_t AAudioBackend::dataCallback(AAudioStream*, void* userData,
                                        void* audioData, std::int32_t numFrames) noexcept {
    auto* self = static_cast<AAudioBackend*>(userData);
    if (self == nullptr || audioData == nullptr || numFrames <= 0 ||
        self->disconnected_.load(std::memory_order_acquire)) return AAUDIO_CALLBACK_RESULT_STOP;
    AudioEngine* engine = self->engine_;
    if (engine == nullptr) return AAUDIO_CALLBACK_RESULT_STOP;
    engine->render(static_cast<float*>(audioData), static_cast<std::size_t>(numFrames), 2);
    return AAUDIO_CALLBACK_RESULT_CONTINUE;
}

void AAudioBackend::errorCallback(AAudioStream*, void* userData, std::int32_t error) noexcept {
    auto* self = static_cast<AAudioBackend*>(userData);
    if (self == nullptr) return;
    self->lastError_.store(error, std::memory_order_relaxed);
    self->disconnected_.store(true, std::memory_order_release);
}

} // namespace kyrevex::audio

#endif // __ANDROID__
