#pragma once

#ifdef __ANDROID__

#include <atomic>
#include <cstdint>

struct AAudioStream;

namespace kyrevex::audio {
class AudioEngine;

struct AAudioBackendStatus {
    bool open{false};
    bool running{false};
    bool disconnected{false};
    std::int32_t sampleRate{0};
    std::int32_t channelCount{0};
    std::int32_t lastError{0};
};

// Android API 26+. The AAudio callback only asks AudioEngine to render PCM;
// it never allocates, blocks, decodes files, or calls game/UI code.
class AAudioBackend final {
public:
    AAudioBackend() = default;
    ~AAudioBackend();
    AAudioBackend(const AAudioBackend&) = delete;
    AAudioBackend& operator=(const AAudioBackend&) = delete;

    [[nodiscard]] bool start(AudioEngine& engine, std::int32_t requestedSampleRate = 0) noexcept;
    void stop() noexcept;
    [[nodiscard]] AAudioBackendStatus status() const noexcept;

private:
    static std::int32_t dataCallback(AAudioStream* stream, void* userData,
                                     void* audioData, std::int32_t numFrames) noexcept;
    static void errorCallback(AAudioStream* stream, void* userData,
                              std::int32_t error) noexcept;

    AAudioStream* stream_{nullptr};
    AudioEngine* engine_{nullptr};
    std::atomic<bool> disconnected_{false};
    std::atomic<std::int32_t> lastError_{0};
};

} // namespace kyrevex::audio

#endif // __ANDROID__
