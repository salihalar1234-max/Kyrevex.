#pragma once

#include "StoreSystem.hpp"

#include <array>
#include <string_view>

namespace kyrevex::economy {

struct StoreCardModel {
    OfferId id{OfferId::Potion};
    std::string_view key;
    std::string_view icon;
    std::string_view title;
    std::string_view description;
    std::string_view actionLabel;
    std::string_view statusLabel;
    std::int64_t price{0};
    int owned{0};
    int cap{0};
    bool actionEnabled{false};
};

struct StoreScreenModel {
    std::int64_t coinBalance{0};
    std::array<StoreCardModel, static_cast<std::size_t>(OfferId::Count)> cards{};
    bool valid{false};
};

// Produces renderer-ready, localized card data. It does not own UI widgets;
// touch/click handlers call StoreSystem::purchase with the selected OfferId.
class StoreScreenPresenter final {
public:
    [[nodiscard]] static StoreScreenModel build(const PlayerEconomy& player,
                                                 Language language) noexcept;
};

} // namespace kyrevex::economy
