#include "StoreSystem.hpp"

#include <algorithm>
#include <charconv>
#include <cmath>
#include <limits>
#include <sstream>
#include <iomanip>
#include <string>

namespace kyrevex::economy {
namespace {
constexpr int kPotionCap = 99;
constexpr int kHerbCap = 300;
constexpr int kEssenceCap = 1000;
constexpr int kRationCap = 99;
constexpr int kBladeMaxTier = 5;
constexpr int kArmorMaxTier = 4;
constexpr int kRuneMaxTier = 3;
constexpr int kInfusionMaxTier = 3;

constexpr std::array<OfferDefinition, static_cast<std::size_t>(OfferId::Count)> kCatalog{{
    {OfferId::Potion, "potion", "⚗", {"جرعة علاج", "Healing Potion", "İyileştirme İksiri"},
     {"قارورة تستعيد حتى 58 نقطة صحة.", "Restores up to 58 health.", "58 cana kadar sağlık yeniler."}},
    {OfferId::PotionPack, "potionPack", "✚", {"حزمة جرعات النبض", "Pulse Potion Pack", "Nabız İksiri Paketi"},
     {"ثلاث جرعات علاج في حزمة واحدة.", "Three healing potions in one pack.", "Tek pakette üç iyileştirme iksiri."}},
    {OfferId::Herbs, "herbs", "❧", {"أعشاب الضوء", "Light Herbs", "Işık Otları"},
     {"تُستخدم لصناعة الجرعات والمؤونة.", "Used to craft potions and trail rations.", "İksir ve yol azığı üretiminde kullanılır."}},
    {OfferId::HerbBundle, "herbBundle", "🌿", {"حزمة أعشاب الرحّالة", "Wayfarer Herb Bundle", "Gezgin Ot Paketi"},
     {"ست أعشاب لمغامرة أطول.", "Six herbs for longer journeys.", "Uzun yolculuklar için altı ot."}},
    {OfferId::Essence, "essence", "✧", {"بلورة أثير", "Aether Crystal", "Eter Kristali"},
     {"مادة نادرة لصقل السيف والرونات.", "Rare material for blade infusion and runes.", "Kılıç özü ve rünler için nadir malzeme."}},
    {OfferId::EssencePack, "essencePack", "❖", {"حزمة بلورات نقية", "Pure Crystal Set", "Saf Kristal Seti"},
     {"ثلاث بلورات للتطويرات المتقدمة.", "Three crystals for advanced upgrades.", "Gelişmiş geliştirmeler için üç kristal."}},
    {OfferId::Ration, "ration", "🥖", {"مؤونة الطريق", "Trail Ration", "Yol Azığı"},
     {"تستعيد جزءاً من الصحة وكل طاقة الأثير.", "Restores some health and all Aether energy.", "Bir miktar sağlık ve tüm Eter enerjisini yeniler."}},
    {OfferId::BladeUpgrade, "bladeUpgrade", "⚔", {"صقل نصل الأثير", "Aether Blade Temper", "Eter Kılıcı İşleme"},
     {"ترقية دائمة للسيف؛ الحد الأقصى 5.", "Permanent blade upgrade; maximum rank 5.", "Kalıcı kılıç geliştirmesi; en fazla 5. seviye."}},
    {OfferId::ArmorUpgrade, "armorUpgrade", "🛡", {"درع حارس الحجاب", "Veilwarden Armor", "Perde Muhafızı Zırhı"},
     {"ترقية دائمة تزيد الصحة القصوى؛ الحد الأقصى 4.", "Permanent upgrade that increases max health; maximum rank 4.", "Maksimum sağlığı artıran kalıcı geliştirme; en fazla 4. seviye."}},
    {OfferId::CrimsonCloak, "cloakCrimson", "◈", {"عباءة الشفق القرمزي", "Crimson Dusk Cloak", "Kızıl Alacakaranlık Pelerini"},
     {"تُفتح مرة واحدة ويمكن تجهيزها مجاناً لاحقاً.", "Unlock once, then re-equip for free.", "Bir kez açılır, sonra ücretsiz tekrar kuşanılır."}},
    {OfferId::VioletCloak, "cloakViolet", "✦", {"عباءة الشق البنفسجي", "Violet Rift Cloak", "Menekşe Yarık Pelerini"},
     {"تُفتح مرة واحدة ويمكن تجهيزها مجاناً لاحقاً.", "Unlock once, then re-equip for free.", "Bir kez açılır, sonra ücretsiz tekrar kuşanılır."}}
}};

constexpr bool isResourceOffer(OfferId id) noexcept {
    return id == OfferId::Potion || id == OfferId::PotionPack ||
           id == OfferId::Herbs || id == OfferId::HerbBundle ||
           id == OfferId::Essence || id == OfferId::EssencePack || id == OfferId::Ration;
}

constexpr std::size_t index(OfferId id) noexcept { return static_cast<std::size_t>(id); }
constexpr std::size_t index(Appearance appearance) noexcept { return static_cast<std::size_t>(appearance); }

int& amountFor(PlayerEconomy& p, OfferId id) noexcept {
    switch (id) {
        case OfferId::Potion:
        case OfferId::PotionPack: return p.potions;
        case OfferId::Herbs:
        case OfferId::HerbBundle: return p.herbs;
        case OfferId::Essence:
        case OfferId::EssencePack: return p.essence;
        case OfferId::Ration: return p.trailRations;
        default: return p.potions;
    }
}

int amountFor(const PlayerEconomy& p, OfferId id) noexcept {
    switch (id) {
        case OfferId::Potion:
        case OfferId::PotionPack: return p.potions;
        case OfferId::Herbs:
        case OfferId::HerbBundle: return p.herbs;
        case OfferId::Essence:
        case OfferId::EssencePack: return p.essence;
        case OfferId::Ration: return p.trailRations;
        default: return 0;
    }
}

int capFor(OfferId id) noexcept {
    switch (id) {
        case OfferId::Potion:
        case OfferId::PotionPack: return kPotionCap;
        case OfferId::Herbs:
        case OfferId::HerbBundle: return kHerbCap;
        case OfferId::Essence:
        case OfferId::EssencePack: return kEssenceCap;
        case OfferId::Ration: return kRationCap;
        default: return 0;
    }
}

int amountForOffer(OfferId id) noexcept {
    switch (id) {
        case OfferId::Potion: return 1;
        case OfferId::PotionPack: return 3;
        case OfferId::Herbs: return 3;
        case OfferId::HerbBundle: return 6;
        case OfferId::Essence: return 1;
        case OfferId::EssencePack: return 3;
        case OfferId::Ration: return 1;
        default: return 0;
    }
}

Appearance appearanceFor(OfferId id) noexcept {
    return id == OfferId::CrimsonCloak ? Appearance::Crimson : Appearance::Violet;
}
} // namespace

const std::array<OfferDefinition, static_cast<std::size_t>(OfferId::Count)>& StoreSystem::catalog() noexcept {
    return kCatalog;
}

bool StoreSystem::isValid(const PlayerEconomy& p) noexcept {
    if (p.coins < 0 || p.potions < 0 || p.potions > kPotionCap ||
        p.herbs < 0 || p.herbs > kHerbCap || p.essence < 0 || p.essence > kEssenceCap ||
        p.trailRations < 0 || p.trailRations > kRationCap ||
        p.swordTier < 0 || p.swordTier > kBladeMaxTier ||
        p.armorTier < 0 || p.armorTier > kArmorMaxTier ||
        p.runeTier < 0 || p.runeTier > kRuneMaxTier ||
        p.infusionTier < 0 || p.infusionTier > kInfusionMaxTier ||
        p.veilReputation < 0 || p.veilReputation > 1000 ||
        p.maxHp <= 0 || p.maxHp > 1000000 || p.hp < 0 || p.hp > p.maxHp ||
        p.maxEnergy <= 0 || p.maxEnergy > 1000000 || p.energy < 0 || p.energy > p.maxEnergy ||
        p.damage < 0 || p.damage > 1000000 || !std::isfinite(p.criticalChance) ||
        p.criticalChance < 0.0F || p.criticalChance > 0.45F ||
        index(p.equippedAppearance) >= index(Appearance::Count)) return false;
    return p.ownedAppearances[index(Appearance::Emerald)] &&
           p.ownedAppearances[index(p.equippedAppearance)];
}

std::int64_t StoreSystem::price(const PlayerEconomy& p, OfferId id) noexcept {
    switch (id) {
        case OfferId::Potion: return 35;
        case OfferId::PotionPack: return 88;
        case OfferId::Herbs: return 48;
        case OfferId::HerbBundle: return 82;
        case OfferId::Essence: return 90;
        case OfferId::EssencePack: return 245;
        case OfferId::Ration: return 65;
        case OfferId::BladeUpgrade: return 70 + static_cast<std::int64_t>(std::max(0, p.swordTier)) * 65;
        case OfferId::ArmorUpgrade: return 80 + static_cast<std::int64_t>(std::max(0, p.armorTier)) * 70;
        case OfferId::CrimsonCloak: return 180;
        case OfferId::VioletCloak: return 220;
        case OfferId::Count: return std::numeric_limits<std::int64_t>::max();
    }
    return std::numeric_limits<std::int64_t>::max();
}

OfferState StoreSystem::inspect(const PlayerEconomy& p, OfferId id) noexcept {
    OfferState out{};
    out.id = id;
    if (!isValid(p) || index(id) >= index(OfferId::Count)) {
        out.blockedBy = ResultCode::InvalidState;
        return out;
    }
    out.price = price(p, id);
    if (id == OfferId::CrimsonCloak || id == OfferId::VioletCloak) {
        const auto appearance = appearanceFor(id);
        out.alreadyOwned = p.ownedAppearances[index(appearance)];
        out.owned = out.alreadyOwned ? 1 : 0;
        out.canBuy = out.alreadyOwned ? p.equippedAppearance != appearance : p.coins >= out.price;
        out.blockedBy = out.alreadyOwned
            ? (out.canBuy ? ResultCode::Success : ResultCode::AlreadyEquipped)
            : (out.canBuy ? ResultCode::Success : ResultCode::InsufficientCoins);
        return out;
    }
    if (id == OfferId::BladeUpgrade) {
        out.owned = p.swordTier; out.cap = kBladeMaxTier;
        out.canBuy = p.swordTier < kBladeMaxTier && p.coins >= out.price;
        out.blockedBy = p.swordTier >= kBladeMaxTier ? ResultCode::MaxTier :
            (out.canBuy ? ResultCode::Success : ResultCode::InsufficientCoins);
        return out;
    }
    if (id == OfferId::ArmorUpgrade) {
        out.owned = p.armorTier; out.cap = kArmorMaxTier;
        out.canBuy = p.armorTier < kArmorMaxTier && p.coins >= out.price;
        out.blockedBy = p.armorTier >= kArmorMaxTier ? ResultCode::MaxTier :
            (out.canBuy ? ResultCode::Success : ResultCode::InsufficientCoins);
        return out;
    }
    if (!isResourceOffer(id)) { out.blockedBy = ResultCode::UnknownOffer; return out; }
    const int stock = amountFor(p, id);
    out.owned = stock; out.cap = capFor(id);
    const bool room = stock + amountForOffer(id) <= out.cap;
    out.canBuy = room && p.coins >= out.price;
    out.blockedBy = !room ? ResultCode::InventoryFull :
        (out.canBuy ? ResultCode::Success : ResultCode::InsufficientCoins);
    return out;
}

ActionResult StoreSystem::failure(ResultCode code) noexcept { return ActionResult{code}; }

ActionResult StoreSystem::purchase(PlayerEconomy& p, OfferId id) noexcept {
    if (!isValid(p)) return failure(ResultCode::InvalidState);
    if (index(id) >= index(OfferId::Count)) return failure(ResultCode::UnknownOffer);

    const OfferState state = inspect(p, id);
    if (!state.canBuy) return failure(state.blockedBy);

    if (id == OfferId::CrimsonCloak || id == OfferId::VioletCloak) {
        const Appearance appearance = appearanceFor(id);
        if (p.ownedAppearances[index(appearance)]) {
            p.equippedAppearance = appearance;
            return ActionResult{ResultCode::EquippedExisting};
        }
        p.coins -= state.price;
        p.ownedAppearances[index(appearance)] = true;
        p.equippedAppearance = appearance;
        return ActionResult{ResultCode::Success, state.price, 1};
    }

    p.coins -= state.price;
    if (isResourceOffer(id)) {
        int& stock = amountFor(p, id);
        const int amount = amountForOffer(id);
        stock += amount;
        return ActionResult{ResultCode::Success, state.price, amount};
    }
    if (id == OfferId::BladeUpgrade) {
        if (p.damage > 999994) return failure(ResultCode::InvalidState);
        ++p.swordTier;
        p.damage += 6;
        return ActionResult{ResultCode::Success, state.price, p.swordTier, 0, 10};
    }
    if (id == OfferId::ArmorUpgrade) {
        if (p.maxHp > 999988) return failure(ResultCode::InvalidState);
        ++p.armorTier;
        p.maxHp += 12;
        p.hp = std::min(p.maxHp, p.hp + 12);
        return ActionResult{ResultCode::Success, state.price, p.armorTier};
    }
    return failure(ResultCode::UnknownOffer);
}

ActionResult StoreSystem::usePotion(PlayerEconomy& p) noexcept {
    if (!isValid(p)) return failure(ResultCode::InvalidState);
    if (p.potions <= 0) return failure(ResultCode::NoConsumable);
    if (p.hp >= p.maxHp) return failure(ResultCode::HealthFull);
    const int healed = std::min(58, p.maxHp - p.hp);
    --p.potions;
    p.hp += healed;
    return ActionResult{ResultCode::Success, 0, healed};
}

ActionResult StoreSystem::craftPotion(PlayerEconomy& p) noexcept {
    if (!isValid(p)) return failure(ResultCode::InvalidState);
    if (p.herbs < 3) return failure(ResultCode::InsufficientResources);
    if (p.potions >= kPotionCap) return failure(ResultCode::InventoryFull);
    p.herbs -= 3; ++p.potions;
    return ActionResult{ResultCode::Success, 0, 1, 3};
}

ActionResult StoreSystem::craftTrailRation(PlayerEconomy& p) noexcept {
    if (!isValid(p)) return failure(ResultCode::InvalidState);
    if (p.herbs < 4) return failure(ResultCode::InsufficientResources);
    if (p.trailRations >= kRationCap) return failure(ResultCode::InventoryFull);
    p.herbs -= 4; ++p.trailRations;
    return ActionResult{ResultCode::Success, 0, 1, 4};
}

ActionResult StoreSystem::useTrailRation(PlayerEconomy& p) noexcept {
    if (!isValid(p)) return failure(ResultCode::InvalidState);
    if (p.trailRations <= 0) return failure(ResultCode::NoConsumable);
    const int healed = static_cast<int>(std::lround(static_cast<double>(p.maxHp) * 0.32));
    const int actualHeal = std::min(healed, p.maxHp - p.hp);
    const int restoredEnergy = p.maxEnergy - p.energy;
    --p.trailRations;
    p.hp += actualHeal;
    p.energy = p.maxEnergy;
    return ActionResult{ResultCode::Success, 0, actualHeal, restoredEnergy};
}

ActionResult StoreSystem::craftRune(PlayerEconomy& p) noexcept {
    if (!isValid(p)) return failure(ResultCode::InvalidState);
    if (p.runeTier >= kRuneMaxTier) return failure(ResultCode::MaxTier);
    const int requiredRep = p.runeTier == 1 ? 180 : p.runeTier == 2 ? 650 : 0;
    if (p.veilReputation < requiredRep) return failure(ResultCode::RankRequired);
    const double discount = p.veilReputation >= 360 ? 0.15 :
                            p.veilReputation >= 180 ? 0.08 :
                            p.veilReputation >= 60 ? 0.04 : 0.0;
    const auto coins = static_cast<std::int64_t>(std::ceil((120 + p.runeTier * 95) * (1.0 - discount)));
    const int essenceCost = 2 + p.runeTier;
    const int herbsCost = 3 + p.runeTier;
    if (p.coins < coins || p.essence < essenceCost || p.herbs < herbsCost)
        return failure(ResultCode::InsufficientResources);
    p.coins -= coins; p.essence -= essenceCost; p.herbs -= herbsCost; ++p.runeTier;
    return ActionResult{ResultCode::Success, coins, p.runeTier, essenceCost + herbsCost};
}

ActionResult StoreSystem::upgradeInfusion(PlayerEconomy& p) noexcept {
    if (!isValid(p)) return failure(ResultCode::InvalidState);
    if (p.infusionTier >= kInfusionMaxTier) return failure(ResultCode::MaxTier);
    const std::int64_t coins = 75 + static_cast<std::int64_t>(p.infusionTier) * 60;
    const int essenceCost = 2 + p.infusionTier * 2;
    if (p.coins < coins || p.essence < essenceCost) return failure(ResultCode::InsufficientResources);
    p.coins -= coins; p.essence -= essenceCost; ++p.infusionTier;
    p.criticalChance = std::min(0.45F, p.criticalChance + 0.035F);
    p.damage += 2;
    return ActionResult{ResultCode::Success, coins, p.infusionTier, essenceCost};
}


std::string StoreSystem::serializePlayer(const PlayerEconomy& p) {
    if (!isValid(p)) return {};
    std::ostringstream out;
    out << "KYREVEX_ECONOMY 1\n"
        << "coins " << p.coins << '\n'
        << "potions " << p.potions << '\n'
        << "herbs " << p.herbs << '\n'
        << "essence " << p.essence << '\n'
        << "trailRations " << p.trailRations << '\n'
        << "swordTier " << p.swordTier << '\n'
        << "armorTier " << p.armorTier << '\n'
        << "runeTier " << p.runeTier << '\n'
        << "infusionTier " << p.infusionTier << '\n'
        << "veilReputation " << p.veilReputation << '\n'
        << "hp " << p.hp << '\n'
        << "maxHp " << p.maxHp << '\n'
        << "energy " << p.energy << '\n'
        << "maxEnergy " << p.maxEnergy << '\n'
        << "damage " << p.damage << '\n'
        << std::fixed << std::setprecision(6)
        << "criticalChance " << p.criticalChance << '\n'
        << "ownedEmerald " << (p.ownedAppearances[index(Appearance::Emerald)] ? 1 : 0) << '\n'
        << "ownedCrimson " << (p.ownedAppearances[index(Appearance::Crimson)] ? 1 : 0) << '\n'
        << "ownedViolet " << (p.ownedAppearances[index(Appearance::Violet)] ? 1 : 0) << '\n'
        << "equippedAppearance " << static_cast<unsigned int>(p.equippedAppearance) << '\n';
    return out.str();
}

std::optional<PlayerEconomy> StoreSystem::deserializePlayer(std::string_view data) noexcept {
    try {
        std::istringstream input{std::string(data)};
        std::string header;
        std::getline(input, header);
        if (header != "KYREVEX_ECONOMY 1") return std::nullopt;

        PlayerEconomy p{};
        std::array<bool, 20> seen{};
        const auto parseInteger = [](const std::string& token, auto& target) {
            const char* begin = token.data();
            const char* end = begin + token.size();
            const auto result = std::from_chars(begin, end, target);
            return result.ec == std::errc{} && result.ptr == end;
        };
        const auto parseFloat = [](const std::string& token, float& target) {
            const char* begin = token.data();
            const char* end = begin + token.size();
            const auto result = std::from_chars(begin, end, target, std::chars_format::general);
            return result.ec == std::errc{} && result.ptr == end;
        };

        std::string key, value;
        while (input >> key) {
            if (!(input >> value)) return std::nullopt;
            std::size_t slot = seen.size();
            bool parsed = false;
            if (key == "coins") { slot=0; parsed=parseInteger(value,p.coins); }
            else if (key == "potions") { slot=1; parsed=parseInteger(value,p.potions); }
            else if (key == "herbs") { slot=2; parsed=parseInteger(value,p.herbs); }
            else if (key == "essence") { slot=3; parsed=parseInteger(value,p.essence); }
            else if (key == "trailRations") { slot=4; parsed=parseInteger(value,p.trailRations); }
            else if (key == "swordTier") { slot=5; parsed=parseInteger(value,p.swordTier); }
            else if (key == "armorTier") { slot=6; parsed=parseInteger(value,p.armorTier); }
            else if (key == "runeTier") { slot=7; parsed=parseInteger(value,p.runeTier); }
            else if (key == "infusionTier") { slot=8; parsed=parseInteger(value,p.infusionTier); }
            else if (key == "veilReputation") { slot=9; parsed=parseInteger(value,p.veilReputation); }
            else if (key == "hp") { slot=10; parsed=parseInteger(value,p.hp); }
            else if (key == "maxHp") { slot=11; parsed=parseInteger(value,p.maxHp); }
            else if (key == "energy") { slot=12; parsed=parseInteger(value,p.energy); }
            else if (key == "maxEnergy") { slot=13; parsed=parseInteger(value,p.maxEnergy); }
            else if (key == "damage") { slot=14; parsed=parseInteger(value,p.damage); }
            else if (key == "criticalChance") { slot=15; parsed=parseFloat(value,p.criticalChance); }
            else if (key == "ownedEmerald" || key == "ownedCrimson" || key == "ownedViolet") {
                slot = key == "ownedEmerald" ? 16 : key == "ownedCrimson" ? 17 : 18;
                int flag = -1;
                parsed = parseInteger(value, flag) && (flag == 0 || flag == 1);
                if (parsed) p.ownedAppearances[slot - 16] = flag == 1;
            }
            else if (key == "equippedAppearance") {
                slot=19;
                unsigned int appearance = 0;
                parsed=parseInteger(value,appearance) && appearance < static_cast<unsigned int>(Appearance::Count);
                if (parsed) p.equippedAppearance = static_cast<Appearance>(appearance);
            }
            else {
                // Unknown fields are ignored for forward-compatible additive changes.
                continue;
            }
            if (!parsed || slot >= seen.size() || seen[slot]) return std::nullopt;
            seen[slot] = true;
        }
        for (const bool fieldSeen : seen) if (!fieldSeen) return std::nullopt;
        if (!isValid(p)) return std::nullopt;
        return p;
    } catch (...) {
        return std::nullopt;
    }
}

std::string_view StoreSystem::localizedName(OfferId id, Language language) noexcept {
    if (index(id) >= kCatalog.size() || static_cast<std::size_t>(language) >= 3U) return {};
    return kCatalog[index(id)].name[static_cast<std::size_t>(language)];
}

} // namespace kyrevex::economy
