#include "AudioEngine.hpp"

#include <algorithm>
#include <bit>
#include <cmath>
#include <cstring>
#include <limits>
#include <utility>

namespace kyrevex::audio {
namespace {
[[nodiscard]] std::uint16_t u16(std::span<const std::uint8_t> b, std::size_t p) noexcept {
    return static_cast<std::uint16_t>(b[p]) |
           static_cast<std::uint16_t>(static_cast<std::uint16_t>(b[p + 1]) << 8U);
}
[[nodiscard]] std::uint32_t u32(std::span<const std::uint8_t> b, std::size_t p) noexcept {
    return static_cast<std::uint32_t>(b[p]) |
           (static_cast<std::uint32_t>(b[p + 1]) << 8U) |
           (static_cast<std::uint32_t>(b[p + 2]) << 16U) |
           (static_cast<std::uint32_t>(b[p + 3]) << 24U);
}
[[nodiscard]] bool tag(std::span<const std::uint8_t> b, std::size_t p,
                       const char (&value)[5]) noexcept {
    return p + 4 <= b.size() && std::memcmp(b.data() + p, value, 4) == 0;
}
[[nodiscard]] float cleanSample(float sample) noexcept {
    return std::isfinite(sample) ? std::clamp(sample, -1.0F, 1.0F) : 0.0F;
}
} // namespace

std::size_t PcmClip::frames() const noexcept {
    return channels == 0 ? 0 : samples.size() / channels;
}

bool PcmClip::valid() const noexcept {
    if (sampleRate < 8000 || sampleRate > 192000 ||
        (channels != 1 && channels != 2) || samples.empty() || samples.size() % channels != 0) {
        return false;
    }
    return std::all_of(samples.begin(), samples.end(), [](float value) {
        return std::isfinite(value) && value >= -1.0F && value <= 1.0F;
    });
}

PcmClip PcmClip::fromWav(std::span<const std::uint8_t> bytes, std::size_t maxFrames) {
    PcmClip result{};
    if (bytes.size() < 44 || !tag(bytes, 0, "RIFF") || !tag(bytes, 8, "WAVE")) return result;

    std::uint16_t format = 0;
    std::uint16_t channelsValue = 0;
    std::uint16_t bitsPerSample = 0;
    std::uint32_t sampleRateValue = 0;
    std::span<const std::uint8_t> data{};
    bool haveFmt = false;
    std::size_t offset = 12;
    while (offset + 8 <= bytes.size()) {
        const std::uint32_t chunkSize = u32(bytes, offset + 4);
        const std::size_t chunkStart = offset + 8;
        if (chunkSize > bytes.size() - chunkStart) return {};
        if (tag(bytes, offset, "fmt ")) {
            if (chunkSize < 16) return {};
            format = u16(bytes, chunkStart);
            channelsValue = u16(bytes, chunkStart + 2);
            sampleRateValue = u32(bytes, chunkStart + 4);
            bitsPerSample = u16(bytes, chunkStart + 14);
            haveFmt = true;
        } else if (tag(bytes, offset, "data")) {
            data = bytes.subspan(chunkStart, chunkSize);
        }
        const std::size_t padded = static_cast<std::size_t>(chunkSize) + (chunkSize & 1U);
        if (padded > bytes.size() - chunkStart) break;
        offset = chunkStart + padded;
    }
    if (!haveFmt || data.empty() || (channelsValue != 1 && channelsValue != 2) ||
        sampleRateValue < 8000 || sampleRateValue > 192000) return {};
    if (!((format == 1 && bitsPerSample == 16) || (format == 3 && bitsPerSample == 32))) return {};

    const std::size_t bytesPerSample = bitsPerSample / 8;
    const std::size_t frameBytes = bytesPerSample * channelsValue;
    if (frameBytes == 0 || data.size() % frameBytes != 0) return {};
    const std::size_t frameCount = data.size() / frameBytes;
    if (frameCount == 0 || frameCount > maxFrames ||
        frameCount > std::numeric_limits<std::size_t>::max() / channelsValue) return {};

    result.sampleRate = sampleRateValue;
    result.channels = static_cast<std::uint8_t>(channelsValue);
    result.samples.resize(frameCount * channelsValue);
    for (std::size_t i = 0; i < result.samples.size(); ++i) {
        if (format == 1) {
            const auto raw = std::bit_cast<std::int16_t>(u16(data, i * 2));
            result.samples[i] = static_cast<float>(raw) / 32768.0F;
        } else {
            const std::uint32_t bits = u32(data, i * 4);
            result.samples[i] = cleanSample(std::bit_cast<float>(bits));
        }
    }
    return result;
}

AudioEngine::AudioEngine() : echoDelay_(static_cast<std::size_t>(48000U / 5U) * 2U, 0.0F) {}

bool AudioEngine::registerClip(ClipId id, PcmClip clip) noexcept {
    if (sealed_ || !clip.valid() || clip.frames() == 0) return false;
    for (const auto& slot : clips_) if (slot.occupied && slot.id == id) return false;
    for (auto& slot : clips_) {
        if (!slot.occupied) {
            slot.id = id;
            slot.clip = std::move(clip);
            slot.occupied = true;
            return true;
        }
    }
    return false;
}

bool AudioEngine::sealAssets() noexcept {
    if (sealed_) return false;
    bool any = false;
    for (const auto& slot : clips_) any = any || slot.occupied;
    sealed_ = any;
    return sealed_;
}

bool AudioEngine::hasClip(ClipId id) const noexcept { return findClip(id) != nullptr; }

bool AudioEngine::play(ClipId id, Bus bus, float gain, bool loop) noexcept {
    if (!sealed_ || !hasClip(id)) return false;
    if (static_cast<unsigned>(bus) > static_cast<unsigned>(Bus::Ambience)) return false;
    if (!std::isfinite(gain)) return false;
    return enqueue(Command{CommandType::Play, id, bus, std::clamp(gain, 0.0F, 2.0F), loop});
}

bool AudioEngine::stopBus(Bus bus) noexcept {
    if (static_cast<unsigned>(bus) > static_cast<unsigned>(Bus::Ambience)) return false;
    return enqueue(Command{CommandType::StopBus, 0, bus, 0.0F, false});
}

bool AudioEngine::stopAll() noexcept {
    return enqueue(Command{CommandType::StopAll, 0, Bus::Sfx, 0.0F, false});
}

bool AudioEngine::enqueue(const Command& command) noexcept {
    auto headRef = std::atomic_ref<std::uint32_t>(commandHead_);
    const std::uint32_t head = headRef.load(std::memory_order_relaxed);
    const std::uint32_t tail = std::atomic_ref<std::uint32_t>(commandTail_).load(std::memory_order_acquire);
    if (head - tail >= CommandCapacity) {
        droppedCommands_.fetch_add(1, std::memory_order_relaxed);
        return false;
    }
    commands_[head % CommandCapacity] = command;
    headRef.store(head + 1, std::memory_order_release);
    return true;
}

void AudioEngine::consumeCommands() noexcept {
    auto headRef = std::atomic_ref<std::uint32_t>(commandHead_);
    auto tailRef = std::atomic_ref<std::uint32_t>(commandTail_);
    std::uint32_t tail = tailRef.load(std::memory_order_relaxed);
    const std::uint32_t head = headRef.load(std::memory_order_acquire);
    while (tail != head) {
        const Command command = commands_[tail % CommandCapacity];
        if (command.type == CommandType::StopAll) {
            for (auto& voice : voices_) voice.active = false;
        } else if (command.type == CommandType::StopBus) {
            for (auto& voice : voices_) if (voice.active && voice.bus == command.bus) voice.active = false;
        } else {
            Voice* target = nullptr;
            for (auto& voice : voices_) if (!voice.active) { target = &voice; break; }
            if (target == nullptr) {
                target = &*std::min_element(voices_.begin(), voices_.end(),
                    [](const Voice& a, const Voice& b) { return a.gain < b.gain; });
            }
            *target = Voice{true, command.clip, command.bus, command.gain, 0.0, command.loop};
        }
        ++tail;
    }
    tailRef.store(tail, std::memory_order_release);
    std::uint32_t active = 0;
    for (const auto& voice : voices_) if (voice.active) ++active;
    activeVoices_.store(active, std::memory_order_relaxed);
}

const PcmClip* AudioEngine::findClip(ClipId id) const noexcept {
    for (const auto& slot : clips_) if (slot.occupied && slot.id == id) return &slot.clip;
    return nullptr;
}

float AudioEngine::busGain(Bus bus) const noexcept {
    switch (bus) {
        case Bus::Sfx: return currentMix_.sfx;
        case Bus::Music: return currentMix_.music;
        case Bus::Ambience: return currentMix_.ambience;
    }
    return 0.0F;
}

float AudioEngine::sampleAt(const PcmClip& clip, double frame, std::uint32_t channel) const noexcept {
    const std::size_t count = clip.frames();
    if (count == 0) return 0.0F;
    const auto first = static_cast<std::size_t>(frame);
    const std::size_t second = std::min(first + 1, count - 1);
    const float fraction = static_cast<float>(frame - static_cast<double>(first));
    const std::uint32_t sourceChannel = clip.channels == 1 ? 0U : std::min(channel, 1U);
    const float a = clip.samples[first * clip.channels + sourceChannel];
    const float b = clip.samples[second * clip.channels + sourceChannel];
    return a + (b - a) * fraction;
}

void AudioEngine::apply(const AudioMix& mix, float rampSeconds) noexcept {
    targetMaster_.store(AudioSettings::sanitizeLevel(mix.master), std::memory_order_relaxed);
    targetSfx_.store(AudioSettings::sanitizeLevel(mix.sfx), std::memory_order_relaxed);
    targetMusic_.store(AudioSettings::sanitizeLevel(mix.music), std::memory_order_relaxed);
    targetAmbience_.store(AudioSettings::sanitizeLevel(mix.ambience), std::memory_order_relaxed);
    targetEchoWet_.store(AudioSettings::sanitizeLevel(mix.echoWet), std::memory_order_relaxed);
    const float ramp = std::isfinite(rampSeconds) ? std::clamp(rampSeconds, 0.0F, 2.0F) : 0.08F;
    targetRampSeconds_.store(ramp, std::memory_order_relaxed);
    mixRevision_.fetch_add(1, std::memory_order_release);
}

void AudioEngine::setOutputSampleRate(std::uint32_t sampleRate) noexcept {
    if (sampleRate < 8000 || sampleRate > 192000) return;
    outputSampleRate_ = sampleRate;
    // Called before the platform stream starts; never allocate in render().
    try {
        echoDelay_.assign(static_cast<std::size_t>(sampleRate / 5U) * 2U, 0.0F);
        echoWriteFrame_ = 0;
    } catch (...) {
        echoDelay_.clear();
        echoWriteFrame_ = 0;
    }
}

void AudioEngine::applyMixRevision() noexcept {
    const std::uint32_t revision = mixRevision_.load(std::memory_order_acquire);
    if (revision == appliedMixRevision_) return;
    targetMix_ = MixState{
        targetMaster_.load(std::memory_order_relaxed),
        targetSfx_.load(std::memory_order_relaxed),
        targetMusic_.load(std::memory_order_relaxed),
        targetAmbience_.load(std::memory_order_relaxed),
        targetEchoWet_.load(std::memory_order_relaxed)
    };
    const float seconds = targetRampSeconds_.load(std::memory_order_relaxed);
    mixRampRemaining_ = static_cast<std::uint64_t>(seconds * static_cast<float>(outputSampleRate_));
    if (mixRampRemaining_ == 0) {
        currentMix_ = targetMix_;
        mixStep_ = {};
    } else {
        const float denominator = static_cast<float>(mixRampRemaining_);
        mixStep_ = MixState{
            (targetMix_.master - currentMix_.master) / denominator,
            (targetMix_.sfx - currentMix_.sfx) / denominator,
            (targetMix_.music - currentMix_.music) / denominator,
            (targetMix_.ambience - currentMix_.ambience) / denominator,
            (targetMix_.echoWet - currentMix_.echoWet) / denominator
        };
    }
    appliedMixRevision_ = revision;
}

void AudioEngine::render(float* output, std::size_t frames, std::uint32_t outputChannels) noexcept {
    if (output == nullptr || (outputChannels != 1 && outputChannels != 2) ||
        frames > std::numeric_limits<std::size_t>::max() / outputChannels) return;
    std::fill_n(output, frames * outputChannels, 0.0F);
    if (!sealed_ || outputSampleRate_ == 0) return;
    consumeCommands();
    applyMixRevision();

    for (std::size_t frameIndex = 0; frameIndex < frames; ++frameIndex) {
        if (mixRampRemaining_ > 0) {
            currentMix_.master += mixStep_.master;
            currentMix_.sfx += mixStep_.sfx;
            currentMix_.music += mixStep_.music;
            currentMix_.ambience += mixStep_.ambience;
            currentMix_.echoWet += mixStep_.echoWet;
            --mixRampRemaining_;
            if (mixRampRemaining_ == 0) currentMix_ = targetMix_;
        }
        float left = 0.0F;
        float right = 0.0F;
        for (auto& voice : voices_) {
            if (!voice.active) continue;
            const PcmClip* clip = findClip(voice.clip);
            if (clip == nullptr || clip->frames() == 0) { voice.active = false; continue; }
            const double maxFrame = static_cast<double>(clip->frames());
            if (voice.cursor >= maxFrame) {
                if (voice.loop) voice.cursor = std::fmod(voice.cursor, maxFrame);
                else { voice.active = false; continue; }
            }
            const float gain = voice.gain * currentMix_.master * busGain(voice.bus);
            if (gain > 0.000001F) {
                left += sampleAt(*clip, voice.cursor, 0U) * gain;
                right += sampleAt(*clip, voice.cursor, 1U) * gain;
            }
            voice.cursor += static_cast<double>(clip->sampleRate) / static_cast<double>(outputSampleRate_);
            if (!voice.loop && voice.cursor >= maxFrame) voice.active = false;
        }
        constexpr float headroom = 0.85F;
        left *= headroom;
        right *= headroom;
        const std::size_t delayFrames = echoDelay_.size() / 2U;
        if (currentMix_.echoWet > 0.0001F && delayFrames > 1U) {
            const std::size_t delay = std::min<std::size_t>(outputSampleRate_ / 6U, delayFrames - 1U);
            const std::size_t readFrame = (echoWriteFrame_ + delayFrames - delay) % delayFrames;
            const float echoLeft = echoDelay_[readFrame * 2U];
            const float echoRight = echoDelay_[readFrame * 2U + 1U];
            left += echoLeft * currentMix_.echoWet * 0.30F;
            right += echoRight * currentMix_.echoWet * 0.30F;
            echoDelay_[echoWriteFrame_ * 2U] = std::clamp(left * 0.42F, -0.8F, 0.8F);
            echoDelay_[echoWriteFrame_ * 2U + 1U] = std::clamp(right * 0.42F, -0.8F, 0.8F);
            echoWriteFrame_ = (echoWriteFrame_ + 1U) % delayFrames;
        } else if (delayFrames > 1U) {
            echoDelay_[echoWriteFrame_ * 2U] = 0.0F;
            echoDelay_[echoWriteFrame_ * 2U + 1U] = 0.0F;
            echoWriteFrame_ = (echoWriteFrame_ + 1U) % delayFrames;
        }
        left = std::clamp(left, -1.0F, 1.0F);
        right = std::clamp(right, -1.0F, 1.0F);
        if (outputChannels == 1) output[frameIndex] = (left + right) * 0.5F;
        else {
            output[frameIndex * 2] = left;
            output[frameIndex * 2 + 1] = right;
        }
    }
    const std::uint32_t increment = static_cast<std::uint32_t>(frames);
    const std::uint32_t previous = renderedFramesLow_.fetch_add(increment, std::memory_order_relaxed);
    if (previous > std::numeric_limits<std::uint32_t>::max() - increment) {
        renderedFramesHigh_.fetch_add(1, std::memory_order_relaxed);
    }
    std::uint32_t active = 0;
    for (const auto& voice : voices_) if (voice.active) ++active;
    activeVoices_.store(active, std::memory_order_relaxed);
}

AudioEngineStats AudioEngine::stats() const noexcept {
    std::uint32_t highBefore = 0;
    std::uint32_t low = 0;
    std::uint32_t highAfter = 0;
    do {
        highBefore = renderedFramesHigh_.load(std::memory_order_relaxed);
        low = renderedFramesLow_.load(std::memory_order_relaxed);
        highAfter = renderedFramesHigh_.load(std::memory_order_relaxed);
    } while (highBefore != highAfter);
    const std::uint64_t rendered = (static_cast<std::uint64_t>(highAfter) << 32U) | low;
    return AudioEngineStats{
        rendered,
        droppedCommands_.load(std::memory_order_relaxed),
        activeVoices_.load(std::memory_order_relaxed)
    };
}

} // namespace kyrevex::audio
