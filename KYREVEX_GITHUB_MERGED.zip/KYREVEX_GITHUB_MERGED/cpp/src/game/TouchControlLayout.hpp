#pragma once

#include <array>
#include <cstddef>
#include <cstdint>
#include <optional>
#include <string>
#include <string_view>

namespace kyrevex::input {

enum class TouchControlId : std::uint8_t {
    MovementStick = 0,
    Attack,
    HeavyAttack,
    Jump,
    Guard,
    TargetLock,
    Skill,
    Dash,
    Interact,
    Sprint,
    Map,
    Menu,
    Count
};

inline constexpr std::size_t kTouchControlCount =
    static_cast<std::size_t>(TouchControlId::Count);

struct TouchControlPlacement final {
    // Normalized center coordinates (0..1) and diameter relative to the
    // shorter viewport dimension, so layouts scale across phone/tablet sizes.
    float x{0.5F};
    float y{0.5F};
    float size{0.12F};
    float opacity{0.85F};
    bool visible{true};
};

class TouchControlLayout final {
public:
    static constexpr float kMinSize = 0.055F;
    static constexpr float kMaxSize = 0.30F;

    [[nodiscard]] static TouchControlLayout defaults() noexcept;

    [[nodiscard]] const TouchControlPlacement* get(TouchControlId id) const noexcept;
    [[nodiscard]] bool setPosition(TouchControlId id, float x, float y) noexcept;
    [[nodiscard]] bool setSize(TouchControlId id, float size) noexcept;
    [[nodiscard]] bool setOpacity(TouchControlId id, float opacity) noexcept;
    [[nodiscard]] bool setVisible(TouchControlId id, bool visible) noexcept;
    void setLeftHanded(bool enabled) noexcept;
    [[nodiscard]] bool isLeftHanded() const noexcept { return leftHanded_; }

    [[nodiscard]] const std::array<TouchControlPlacement, kTouchControlCount>&
    controls() const noexcept { return controls_; }

    [[nodiscard]] std::string serialize() const;
    [[nodiscard]] static std::optional<TouchControlLayout> deserialize(std::string_view data);

private:
    [[nodiscard]] static bool validId(TouchControlId id) noexcept;
    [[nodiscard]] static bool validPlacement(const TouchControlPlacement& placement) noexcept;
    [[nodiscard]] static std::size_t indexOf(TouchControlId id) noexcept;
    static void constrainPosition(TouchControlPlacement& placement) noexcept;

    std::array<TouchControlPlacement, kTouchControlCount> controls_{};
    bool leftHanded_{false};
};

} // namespace kyrevex::input
