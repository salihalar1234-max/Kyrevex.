#include "BuiltinAudioAssets.hpp"

#include <algorithm>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <numbers>
#include <vector>

namespace kyrevex::audio {
namespace {
constexpr float kPi = std::numbers::pi_v<float>;
constexpr float kTau = 2.0F * kPi;

float envelope(float t, float duration, float attack, float release) noexcept {
    const float in = attack <= 0.0F ? 1.0F : std::clamp(t / attack, 0.0F, 1.0F);
    const float remaining = duration - t;
    const float out = release <= 0.0F ? 1.0F : std::clamp(remaining / release, 0.0F, 1.0F);
    return in * out;
}

PcmClip makeTone(std::uint32_t rate, float seconds, float frequency,
                 float endFrequency, float amplitude, float phase = 0.0F) {
    const auto frames = static_cast<std::size_t>(static_cast<double>(rate) * seconds);
    PcmClip clip{rate, 1, std::vector<float>(frames)};
    float phaseValue = phase;
    for (std::size_t i = 0; i < frames; ++i) {
        const float t = static_cast<float>(i) / static_cast<float>(rate);
        const float progress = seconds > 0.0F ? t / seconds : 1.0F;
        const float hz = frequency + (endFrequency - frequency) * progress;
        phaseValue += kTau * hz / static_cast<float>(rate);
        clip.samples[i] = std::sin(phaseValue) * amplitude * envelope(t, seconds, 0.008F, 0.045F);
    }
    return clip;
}

PcmClip makeNoiseBurst(std::uint32_t rate, float seconds, float amplitude,
                       std::uint32_t seed, float toneStart, float toneEnd) {
    const auto frames = static_cast<std::size_t>(static_cast<double>(rate) * seconds);
    PcmClip clip{rate, 1, std::vector<float>(frames)};
    std::uint32_t state = seed;
    float phase = 0.0F;
    float lowNoise = 0.0F;
    for (std::size_t i = 0; i < frames; ++i) {
        state = state * 1664525U + 1013904223U;
        const float noise = static_cast<float>((state >> 8U) & 0xffffU) / 32767.5F - 1.0F;
        const float t = static_cast<float>(i) / static_cast<float>(rate);
        const float progress = seconds > 0.0F ? t / seconds : 1.0F;
        const float hz = toneStart + (toneEnd - toneStart) * progress;
        phase += kTau * hz / static_cast<float>(rate);
        lowNoise += (noise - lowNoise) * 0.08F;
        const float body = std::sin(phase) * 0.55F + lowNoise * 0.45F;
        clip.samples[i] = body * amplitude * envelope(t, seconds, 0.003F, seconds * 0.55F);
    }
    return clip;
}

PcmClip makeMusic(std::uint32_t rate, std::uint32_t seconds) {
    const std::size_t frames = static_cast<std::size_t>(rate) * seconds;
    PcmClip clip{rate, 2, std::vector<float>(frames * 2)};
    constexpr float notes[3][4] = {
        {110.00F, 164.81F, 220.00F, 261.63F},
        {98.00F, 146.83F, 196.00F, 246.94F},
        {130.81F, 196.00F, 261.63F, 329.63F}
    };
    const float duration = static_cast<float>(seconds);
    const float blendDuration = 0.24F;
    for (std::size_t i = 0; i < frames; ++i) {
        const float t = static_cast<float>(i) / static_cast<float>(rate);
        const std::size_t section = std::min<std::size_t>(2, static_cast<std::size_t>(t / (duration / 3.0F)));
        float sample = 0.0F;
        for (std::size_t n = 0; n < 4; ++n) {
            const float hz = notes[section][n];
            const float phase = kTau * hz * t;
            const float shimmer = std::sin(kTau * (hz * 2.003F) * t + static_cast<float>(n));
            sample += std::sin(phase) * (n == 0 ? 0.30F : 0.13F) + shimmer * 0.025F;
        }
        sample += std::sin(kTau * 0.125F * t) * 0.07F;
        // Crossfade the final 240 ms to the loop's opening sample region.
        const float tail = duration - t;
        if (tail < blendDuration) {
            const float alpha = std::clamp(tail / blendDuration, 0.0F, 1.0F);
            sample *= alpha;
        }
        sample *= 0.16F;
        const float stereo = std::sin(kTau * 0.035F * t) * 0.08F;
        clip.samples[i * 2] = std::clamp(sample * (1.0F - stereo), -0.45F, 0.45F);
        clip.samples[i * 2 + 1] = std::clamp(sample * (1.0F + stereo), -0.45F, 0.45F);
    }
    return clip;
}

PcmClip makeAmbience(std::uint32_t rate, std::uint32_t seconds) {
    const std::size_t frames = static_cast<std::size_t>(rate) * seconds;
    PcmClip clip{rate, 1, std::vector<float>(frames)};
    std::uint32_t state = 0x4b595256U;
    float filtered = 0.0F;
    const float duration = static_cast<float>(seconds);
    for (std::size_t i = 0; i < frames; ++i) {
        const float t = static_cast<float>(i) / static_cast<float>(rate);
        state = state * 1103515245U + 12345U;
        const float noise = static_cast<float>((state >> 9U) & 0x7fffffU) / 4194303.5F - 1.0F;
        filtered += (noise - filtered) * 0.018F;
        const float wind = std::sin(kTau * 0.19F * t) * 0.35F + std::sin(kTau * 0.073F * t) * 0.20F;
        const float crystal = std::sin(kTau * 523.25F * t) * 0.025F +
                              std::sin(kTau * 659.25F * t + 0.7F) * 0.018F;
        const float tail = duration - t;
        const float loopBlend = tail < 0.24F ? std::clamp(tail / 0.24F, 0.0F, 1.0F) : 1.0F;
        clip.samples[i] = std::clamp((filtered * 0.13F + wind * 0.08F + crystal) * loopBlend,
                                     -0.22F, 0.22F);
    }
    return clip;
}
} // namespace

bool BuiltinAudioAssets::install(AudioEngine& engine, BuiltinAudioConfig config) noexcept {
    if (config.effectsRate < 8000 || config.effectsRate > 192000 ||
        config.loopRate < 8000 || config.loopRate > 192000 ||
        config.loopSeconds < 6 || config.loopSeconds > 30) return false;
    try {
        const bool registered =
            engine.registerClip(static_cast<ClipId>(BuiltinClip::UiConfirm),
                                makeTone(config.effectsRate, 0.16F, 620.0F, 920.0F, 0.26F)) &&
            engine.registerClip(static_cast<ClipId>(BuiltinClip::SwordSlash),
                                makeNoiseBurst(config.effectsRate, 0.28F, 0.34F, 0x534c4153U, 760.0F, 125.0F)) &&
            engine.registerClip(static_cast<ClipId>(BuiltinClip::AetherCast),
                                makeTone(config.effectsRate, 0.52F, 240.0F, 980.0F, 0.22F, 0.4F)) &&
            engine.registerClip(static_cast<ClipId>(BuiltinClip::PlayerHit),
                                makeNoiseBurst(config.effectsRate, 0.19F, 0.40F, 0x48495421U, 145.0F, 62.0F)) &&
            engine.registerClip(static_cast<ClipId>(BuiltinClip::Footstep),
                                makeNoiseBurst(config.effectsRate, 0.10F, 0.20F, 0x53544550U, 92.0F, 48.0F)) &&
            engine.registerClip(static_cast<ClipId>(BuiltinClip::MusicLoop),
                                makeMusic(config.loopRate, config.loopSeconds)) &&
            engine.registerClip(static_cast<ClipId>(BuiltinClip::WorldAmbienceLoop),
                                makeAmbience(config.loopRate, config.loopSeconds));
        if (!registered) return false;
        return engine.sealAssets();
    } catch (...) {
        return false;
    }
}

bool BuiltinAudioAssets::startBackgroundLoops(AudioEngine& engine) noexcept {
    return engine.play(static_cast<ClipId>(BuiltinClip::MusicLoop), Bus::Music, 0.75F, true) &&
           engine.play(static_cast<ClipId>(BuiltinClip::WorldAmbienceLoop), Bus::Ambience, 0.65F, true);
}

bool BuiltinAudioAssets::play(AudioEngine& engine, BuiltinClip clip, float gain) noexcept {
    const Bus bus = (clip == BuiltinClip::MusicLoop) ? Bus::Music :
                    (clip == BuiltinClip::WorldAmbienceLoop) ? Bus::Ambience : Bus::Sfx;
    const bool loop = clip == BuiltinClip::MusicLoop || clip == BuiltinClip::WorldAmbienceLoop;
    return engine.play(static_cast<ClipId>(clip), bus, gain, loop);
}

} // namespace kyrevex::audio
