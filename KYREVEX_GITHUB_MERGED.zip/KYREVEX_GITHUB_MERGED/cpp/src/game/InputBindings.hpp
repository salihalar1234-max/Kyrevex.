#pragma once

#include "game/InputRouter.hpp"

#include <array>
#include <cstddef>
#include <cstdint>
#include <optional>
#include <string>
#include <string_view>

namespace kyrevex::input {

// USB HID Keyboard/Keypad usage IDs. Platform adapters should translate their
// native key/scancode values to these stable IDs before querying this map.
enum class HidKey : std::uint32_t {
    A = 0x04,
    C = 0x06,
    D = 0x07,
    E = 0x08,
    F = 0x09,
    I = 0x0C,
    J = 0x0D,
    M = 0x10,
    Q = 0x14,
    S = 0x16,
    W = 0x1A,
    X = 0x1B,
    Space = 0x2C,
    Escape = 0x29,
    LeftShift = 0xE1,
    LeftAlt = 0xE2
};

struct Binding final {
    Source source{Source::Keyboard};
    std::uint32_t controlId{0};
    Action action{Action::Attack};
};

// Remappable physical controls. A single physical control maps to one action,
// while an action may be mapped to multiple devices (for example keyboard + pad).
class InputBindings final {
public:
    static constexpr std::size_t kMaxBindings = 64;

    [[nodiscard]] static InputBindings defaults() noexcept;

    [[nodiscard]] bool bind(Source source, std::uint32_t controlId,
                            Action action) noexcept;
    [[nodiscard]] bool unbind(Source source, std::uint32_t controlId) noexcept;
    [[nodiscard]] std::optional<Action> actionFor(Source source,
                                                   std::uint32_t controlId) const noexcept;
    [[nodiscard]] std::size_t size() const noexcept { return size_; }

    [[nodiscard]] std::string serialize() const;
    [[nodiscard]] static std::optional<InputBindings> deserialize(std::string_view data);

private:
    struct Slot final {
        bool active{false};
        Binding binding{};
    };

    [[nodiscard]] static bool validSource(Source source) noexcept;
    [[nodiscard]] static bool validAction(Action action) noexcept;

    std::array<Slot, kMaxBindings> slots_{};
    std::size_t size_{0};
};

} // namespace kyrevex::input
