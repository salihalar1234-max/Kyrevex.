#pragma once

#include "AudioSettings.hpp"

#include <array>
#include <atomic>
#include <cstddef>
#include <cstdint>
#include <span>
#include <vector>

namespace kyrevex::audio {

static_assert(std::atomic<float>::is_always_lock_free,
              "Audio callback requires lock-free 32-bit float atomics");
static_assert(std::atomic_ref<std::uint32_t>::is_always_lock_free,
              "Audio callback requires lock-free 32-bit command counters");

using ClipId = std::uint16_t;

struct PcmClip {
    std::uint32_t sampleRate{0};
    std::uint8_t channels{0};
    std::vector<float> samples;

    [[nodiscard]] std::size_t frames() const noexcept;
    [[nodiscard]] bool valid() const noexcept;
    [[nodiscard]] static PcmClip fromWav(std::span<const std::uint8_t> bytes,
                                         std::size_t maxFrames = 15U * 192000U);
};

struct AudioEngineStats {
    std::uint64_t renderedFrames{0};
    std::uint64_t droppedCommands{0};
    std::uint32_t activeVoices{0};
};

// Lock-free SPSC command producer + fixed voice pool. Register clips before
// sealAssets(), then call play/stop from exactly one game thread. render() is
// intended for an audio callback: it does not allocate, lock, or perform I/O.
class AudioEngine final : public AudioOutput {
public:
    static constexpr std::size_t MaxClips = 32;
    static constexpr std::size_t MaxVoices = 24;
    static constexpr std::size_t CommandCapacity = 64;

    AudioEngine();
    AudioEngine(const AudioEngine&) = delete;
    AudioEngine& operator=(const AudioEngine&) = delete;

    [[nodiscard]] bool registerClip(ClipId id, PcmClip clip) noexcept;
    [[nodiscard]] bool sealAssets() noexcept;
    [[nodiscard]] bool assetsSealed() const noexcept { return sealed_; }
    [[nodiscard]] bool hasClip(ClipId id) const noexcept;

    [[nodiscard]] bool play(ClipId id, Bus bus, float gain = 1.0F,
                            bool loop = false) noexcept;
    [[nodiscard]] bool stopBus(Bus bus) noexcept;
    [[nodiscard]] bool stopAll() noexcept;

    void apply(const AudioMix& mix, float rampSeconds) noexcept override;
    void setOutputSampleRate(std::uint32_t sampleRate) noexcept;
    void render(float* output, std::size_t frames, std::uint32_t outputChannels) noexcept;

    [[nodiscard]] AudioEngineStats stats() const noexcept;

private:
    enum class CommandType : std::uint8_t { Play, StopBus, StopAll };
    struct Command {
        CommandType type{CommandType::StopAll};
        ClipId clip{0};
        Bus bus{Bus::Sfx};
        float gain{1.0F};
        bool loop{false};
    };
    struct Voice {
        bool active{false};
        ClipId clip{0};
        Bus bus{Bus::Sfx};
        float gain{1.0F};
        double cursor{0.0};
        bool loop{false};
    };
    struct ClipSlot {
        ClipId id{0};
        bool occupied{false};
        PcmClip clip{};
    };
    struct MixState {
        float master{0.0F};
        float sfx{0.0F};
        float music{0.0F};
        float ambience{0.0F};
        float echoWet{0.0F};
    };

    [[nodiscard]] bool enqueue(const Command& command) noexcept;
    void consumeCommands() noexcept;
    [[nodiscard]] const PcmClip* findClip(ClipId id) const noexcept;
    [[nodiscard]] float busGain(Bus bus) const noexcept;
    [[nodiscard]] float sampleAt(const PcmClip& clip, double frame,
                                 std::uint32_t channel) const noexcept;
    void applyMixRevision() noexcept;

    std::array<ClipSlot, MaxClips> clips_{};
    std::array<Voice, MaxVoices> voices_{};
    std::array<Command, CommandCapacity> commands_{};
    alignas(std::atomic_ref<std::uint32_t>::required_alignment) std::uint32_t commandHead_{0}; // SPSC atomic-ref counter
    alignas(std::atomic_ref<std::uint32_t>::required_alignment) std::uint32_t commandTail_{0}; // SPSC atomic-ref counter
    bool sealed_{false};

    std::atomic<float> targetMaster_{0.92F};
    std::atomic<float> targetSfx_{0.82F};
    std::atomic<float> targetMusic_{0.30F};
    std::atomic<float> targetAmbience_{0.24F};
    std::atomic<float> targetEchoWet_{0.0F};
    std::atomic<float> targetRampSeconds_{0.08F};
    std::atomic<std::uint32_t> mixRevision_{0};
    std::uint32_t appliedMixRevision_{0}; // callback-owned
    MixState currentMix_{};
    MixState targetMix_{};
    MixState mixStep_{};
    std::uint64_t mixRampRemaining_{0};
    std::uint32_t outputSampleRate_{48000};
    std::vector<float> echoDelay_; // allocated/reset before opening the platform stream
    std::size_t echoWriteFrame_{0};

    // Split 64-bit frame counter into lock-free 32-bit atomics for 32-bit ARM.
    std::atomic<std::uint32_t> renderedFramesLow_{0};
    std::atomic<std::uint32_t> renderedFramesHigh_{0};
    std::atomic<std::uint32_t> droppedCommands_{0};
    std::atomic<std::uint32_t> activeVoices_{0};
};

} // namespace kyrevex::audio
