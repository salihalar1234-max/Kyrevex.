#include "StoreScreenModel.hpp"

namespace kyrevex::economy {
namespace {
struct Labels {
    std::string_view buy;
    std::string_view buyCloak;
    std::string_view equip;
    std::string_view equipped;
    std::string_view upgradeBlade;
    std::string_view upgradeArmor;
    std::string_view maxRank;
    std::string_view inventoryFull;
    std::string_view owned;
    std::string_view locked;
    std::string_view level;
};

constexpr std::array<Labels, 3> kLabels{{
    {"شراء", "شراء العباءة", "تجهيز", "مجهّز", "ترقية السيف", "ترقية الدرع", "الحد الأقصى", "المخزون ممتلئ", "مملوك", "غير مملوك", "المستوى"},
    {"Buy", "Buy cloak", "Equip", "Equipped", "Upgrade blade", "Upgrade armor", "MAX RANK", "Inventory full", "Owned", "Locked", "Rank"},
    {"Satın Al", "Pelerini al", "Kuşan", "Kuşanıldı", "Kılıcı yükselt", "Zırhı yükselt", "EN YÜKSEK", "Envanter dolu", "Sahip", "Kilitli", "Seviye"}
}};

constexpr bool isCloak(OfferId id) noexcept {
    return id == OfferId::CrimsonCloak || id == OfferId::VioletCloak;
}

std::string_view statusLabel(ResultCode result, const Labels& labels) noexcept {
    switch (result) {
        case ResultCode::Success: return {};
        case ResultCode::EquippedExisting: return labels.owned;
        case ResultCode::AlreadyEquipped: return labels.equipped;
        case ResultCode::InventoryFull: return labels.inventoryFull;
        case ResultCode::MaxTier: return labels.maxRank;
        case ResultCode::InsufficientCoins: return labels.locked;
        case ResultCode::InsufficientResources: return labels.locked;
        case ResultCode::RankRequired: return labels.locked;
        case ResultCode::NoConsumable: return labels.locked;
        case ResultCode::HealthFull: return labels.locked;
        case ResultCode::UnknownOffer: return labels.locked;
        case ResultCode::InvalidState: return labels.locked;
    }
    return labels.locked;
}
} // namespace

StoreScreenModel StoreScreenPresenter::build(const PlayerEconomy& player,
                                             Language language) noexcept {
    StoreScreenModel model{};
    if (!StoreSystem::isValid(player) || static_cast<std::size_t>(language) >= kLabels.size())
        return model;

    const Labels& labels = kLabels[static_cast<std::size_t>(language)];
    model.valid = true;
    model.coinBalance = player.coins;
    const auto& catalog = StoreSystem::catalog();
    for (std::size_t i = 0; i < catalog.size(); ++i) {
        const OfferDefinition& definition = catalog[i];
        const OfferState state = StoreSystem::inspect(player, definition.id);
        StoreCardModel card{};
        card.id = definition.id;
        card.key = definition.key;
        card.icon = definition.icon;
        card.title = definition.name[static_cast<std::size_t>(language)];
        card.description = definition.description[static_cast<std::size_t>(language)];
        card.price = state.price;
        card.owned = state.owned;
        card.cap = state.cap;
        card.actionEnabled = state.canBuy;
        card.statusLabel = statusLabel(state.blockedBy, labels);

        if (state.blockedBy == ResultCode::MaxTier) {
            card.actionLabel = labels.maxRank;
        } else if (state.blockedBy == ResultCode::InventoryFull) {
            card.actionLabel = labels.inventoryFull;
        } else if (isCloak(definition.id)) {
            if (state.alreadyOwned) {
                card.actionLabel = state.canBuy ? labels.equip : labels.equipped;
            } else {
                card.actionLabel = labels.buyCloak;
            }
        } else if (definition.id == OfferId::BladeUpgrade) {
            card.actionLabel = labels.upgradeBlade;
        } else if (definition.id == OfferId::ArmorUpgrade) {
            card.actionLabel = labels.upgradeArmor;
        } else {
            card.actionLabel = labels.buy;
        }
        model.cards[i] = card;
    }
    return model;
}

} // namespace kyrevex::economy
