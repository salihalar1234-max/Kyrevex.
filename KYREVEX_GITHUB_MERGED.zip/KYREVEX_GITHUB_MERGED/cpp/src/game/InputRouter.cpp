#include "game/InputRouter.hpp"

#include <algorithm>
#include <cmath>

namespace kyrevex::input {
namespace {
[[nodiscard]] bool validActionIndex(Action action) noexcept {
    return static_cast<std::size_t>(action) < kActionCount;
}
} // namespace

bool InputSnapshot::isDown(Action action) const noexcept {
    const auto index = static_cast<std::size_t>(action);
    return index < kActionCount && down[index];
}

bool InputSnapshot::wasPressed(Action action) const noexcept {
    const auto index = static_cast<std::size_t>(action);
    return index < kActionCount && pressed[index];
}

bool InputSnapshot::wasReleased(Action action) const noexcept {
    const auto index = static_cast<std::size_t>(action);
    return index < kActionCount && released[index];
}

bool InputRouter::validSource(Source source) noexcept {
    return source == Source::Keyboard || source == Source::Touch || source == Source::Gamepad;
}

bool InputRouter::validAction(Action action) noexcept {
    return validActionIndex(action);
}

float InputRouter::finiteClamp(float value) noexcept {
    if (!std::isfinite(value)) {
        return 0.0F;
    }
    return std::clamp(value, -1.0F, 1.0F);
}

std::size_t InputRouter::indexOf(Action action) noexcept {
    return static_cast<std::size_t>(action);
}

bool InputRouter::setButton(Source source, std::uint32_t controlId,
                            Action action, bool isDown) noexcept {
    if (!validSource(source) || !validAction(action)) {
        return false;
    }

    ButtonSlot* freeSlot = nullptr;
    for (auto& slot : buttons_) {
        if (slot.active && slot.source == source && slot.controlId == controlId) {
            if (!isDown) {
                slot.active = false;
                return true;
            }
            if (slot.action == action) {
                return true;
            }
            // A physical control may be remapped while held; replace its old action atomically.
            slot.action = action;
            return true;
        }
        if (!slot.active && freeSlot == nullptr) {
            freeSlot = &slot;
        }
    }

    if (!isDown) {
        return false;
    }
    if (freeSlot == nullptr) {
        return false;
    }
    *freeSlot = ButtonSlot{true, source, controlId, action};
    return true;
}

bool InputRouter::setMoveAxis(Source source, std::uint32_t controlId,
                              float x, float y) noexcept {
    if (!validSource(source)) {
        return false;
    }
    AxisSlot* freeSlot = nullptr;
    for (auto& slot : axes_) {
        if (slot.active && slot.source == source && slot.controlId == controlId) {
            slot.x = finiteClamp(x);
            slot.y = finiteClamp(y);
            return true;
        }
        if (!slot.active && freeSlot == nullptr) {
            freeSlot = &slot;
        }
    }
    if (freeSlot == nullptr) {
        return false;
    }
    *freeSlot = AxisSlot{true, source, controlId, finiteClamp(x), finiteClamp(y)};
    return true;
}

bool InputRouter::releaseMoveAxis(Source source, std::uint32_t controlId) noexcept {
    if (!validSource(source)) {
        return false;
    }
    for (auto& slot : axes_) {
        if (slot.active && slot.source == source && slot.controlId == controlId) {
            slot = AxisSlot{};
            return true;
        }
    }
    return false;
}

void InputRouter::releaseControl(Source source, std::uint32_t controlId) noexcept {
    if (!validSource(source)) {
        return;
    }
    for (auto& slot : buttons_) {
        if (slot.active && slot.source == source && slot.controlId == controlId) {
            slot.active = false;
        }
    }
    (void)releaseMoveAxis(source, controlId);
}

void InputRouter::releaseSource(Source source) noexcept {
    if (!validSource(source)) {
        return;
    }
    for (auto& slot : buttons_) {
        if (slot.active && slot.source == source) {
            slot.active = false;
        }
    }
    for (auto& slot : axes_) {
        if (slot.active && slot.source == source) {
            slot = AxisSlot{};
        }
    }
}

void InputRouter::focusLost() noexcept {
    for (auto& slot : buttons_) {
        slot.active = false;
    }
    for (auto& slot : axes_) {
        slot = AxisSlot{};
    }
}

void InputRouter::setDeadzone(float deadzone) noexcept {
    if (!std::isfinite(deadzone)) {
        deadzone_ = kDefaultDeadzone;
        return;
    }
    deadzone_ = std::clamp(deadzone, 0.0F, 0.95F);
}

const InputSnapshot& InputRouter::advanceFrame() noexcept {
    InputSnapshot next{};

    for (const auto& slot : buttons_) {
        if (slot.active && validAction(slot.action)) {
            next.down[indexOf(slot.action)] = true;
        }
    }

    float digitalX = 0.0F;
    float digitalY = 0.0F;
    digitalX += next.down[indexOf(Action::MoveRight)] ? 1.0F : 0.0F;
    digitalX -= next.down[indexOf(Action::MoveLeft)] ? 1.0F : 0.0F;
    digitalY += next.down[indexOf(Action::MoveUp)] ? 1.0F : 0.0F;
    digitalY -= next.down[indexOf(Action::MoveDown)] ? 1.0F : 0.0F;

    float axisX = 0.0F;
    float axisY = 0.0F;
    for (const auto& slot : axes_) {
        if (slot.active) {
            axisX += slot.x;
            axisY += slot.y;
        }
    }

    float x = std::clamp(digitalX + axisX, -1.0F, 1.0F);
    float y = std::clamp(digitalY + axisY, -1.0F, 1.0F);
    const float magnitude = std::sqrt((x * x) + (y * y));
    if (!std::isfinite(magnitude) || magnitude <= deadzone_ || magnitude <= 0.0F) {
        x = 0.0F;
        y = 0.0F;
    } else {
        const float outputMagnitude = std::min(1.0F, (magnitude - deadzone_) / (1.0F - deadzone_));
        const float scale = outputMagnitude / magnitude;
        x *= scale;
        y *= scale;
    }

    next.moveX = x;
    next.moveY = y;
    next.moveMagnitude = std::clamp(std::sqrt((x * x) + (y * y)), 0.0F, 1.0F);

    for (std::size_t i = 0; i < kActionCount; ++i) {
        next.pressed[i] = next.down[i] && !snapshot_.down[i];
        next.released[i] = !next.down[i] && snapshot_.down[i];
    }
    snapshot_ = next;
    return snapshot_;
}

} // namespace kyrevex::input
