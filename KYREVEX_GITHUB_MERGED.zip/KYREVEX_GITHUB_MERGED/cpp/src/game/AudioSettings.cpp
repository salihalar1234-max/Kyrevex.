#include "AudioSettings.hpp"

#include <algorithm>
#include <charconv>
#include <cmath>
#include <iomanip>
#include <sstream>
#include <string>

namespace kyrevex::audio {
namespace {
constexpr std::string_view kHeader{"KYREVEX_AUDIO_SETTINGS 1"};
constexpr float kEchoWet = 0.12F;

AudioSettingsState sanitize(AudioSettingsState value) noexcept {
    value.master = AudioSettings::sanitizeLevel(value.master);
    value.sfx = AudioSettings::sanitizeLevel(value.sfx);
    value.music = AudioSettings::sanitizeLevel(value.music);
    value.ambience = AudioSettings::sanitizeLevel(value.ambience);
    return value;
}
} // namespace

AudioSettings::AudioSettings(AudioSettingsState initial) noexcept {
    const auto safe = sanitize(initial);
    master_.store(safe.master, std::memory_order_relaxed);
    sfx_.store(safe.sfx, std::memory_order_relaxed);
    music_.store(safe.music, std::memory_order_relaxed);
    ambience_.store(safe.ambience, std::memory_order_relaxed);
    enabled_.store(safe.enabled, std::memory_order_relaxed);
}

AudioSettings::AudioSettings(AudioSettings&& other) noexcept
    : AudioSettings(other.state()) {}

AudioSettings& AudioSettings::operator=(AudioSettings&& other) noexcept {
    if (this != &other) {
        const auto safe = other.state();
        master_.store(safe.master, std::memory_order_relaxed);
        sfx_.store(safe.sfx, std::memory_order_relaxed);
        music_.store(safe.music, std::memory_order_relaxed);
        ambience_.store(safe.ambience, std::memory_order_relaxed);
        enabled_.store(safe.enabled, std::memory_order_relaxed);
    }
    return *this;
}

AudioSettingsState AudioSettings::state() const noexcept {
    return AudioSettingsState{
        master_.load(std::memory_order_relaxed),
        sfx_.load(std::memory_order_relaxed),
        music_.load(std::memory_order_relaxed),
        ambience_.load(std::memory_order_relaxed),
        enabled_.load(std::memory_order_relaxed)
    };
}

void AudioSettings::setEnabled(bool enabled) noexcept { enabled_.store(enabled, std::memory_order_relaxed); }
void AudioSettings::setMaster(float value) noexcept { master_.store(sanitizeLevel(value), std::memory_order_relaxed); }

void AudioSettings::setBusLevel(Bus bus, float value) noexcept {
    const float level = sanitizeLevel(value);
    switch (bus) {
        case Bus::Sfx: sfx_.store(level, std::memory_order_relaxed); break;
        case Bus::Music: music_.store(level, std::memory_order_relaxed); break;
        case Bus::Ambience: ambience_.store(level, std::memory_order_relaxed); break;
    }
}

AudioMix AudioSettings::mix(const AudioRuntimeState& runtime) const noexcept {
    const auto current = state();
    const bool audible = current.enabled && runtime.appVisible && runtime.audioFocusGranted;
    const float master = audible ? current.master : 0.0F;
    const float pauseMusicScale = runtime.gamePaused ? 0.45F : 1.0F;
    const float pauseAmbienceScale = runtime.gamePaused ? 0.30F : 1.0F;
    return AudioMix{
        master,
        current.sfx,
        current.music * pauseMusicScale,
        current.ambience * pauseAmbienceScale,
        audible ? kEchoWet : 0.0F
    };
}

void AudioSettings::apply(AudioOutput& output,
                          const AudioRuntimeState& runtime,
                          float rampSeconds) const noexcept {
    const float safeRamp = std::isfinite(rampSeconds)
        ? std::clamp(rampSeconds, 0.0F, 2.0F) : 0.08F;
    output.apply(mix(runtime), safeRamp);
}

std::string AudioSettings::serialize() const {
    std::ostringstream out;
    const auto current = state();
    out << kHeader << '\n' << std::fixed << std::setprecision(4)
        << "master " << current.master << '\n'
        << "sfx " << current.sfx << '\n'
        << "music " << current.music << '\n'
        << "ambience " << current.ambience << '\n'
        << "enabled " << (current.enabled ? 1 : 0) << '\n';
    return out.str();
}

std::optional<AudioSettings> AudioSettings::deserialize(std::string_view data) noexcept {
    try {
        std::istringstream input{std::string(data)};
        std::string header;
        std::getline(input, header);
        if (header != kHeader) return std::nullopt;

        const auto parseFloat = [](const std::string& token, float& target) {
            const char* begin = token.data();
            const char* end = begin + token.size();
            const auto result = std::from_chars(begin, end, target, std::chars_format::general);
            return result.ec == std::errc{} && result.ptr == end;
        };

        AudioSettingsState parsed{};
        bool sawMaster = false, sawSfx = false, sawMusic = false;
        bool sawAmbience = false, sawEnabled = false;
        std::string key;
        std::string value;
        while (input >> key) {
            if (!(input >> value)) return std::nullopt;
            if (key == "master") { if (!parseFloat(value, parsed.master)) return std::nullopt; sawMaster = true; }
            else if (key == "sfx") { if (!parseFloat(value, parsed.sfx)) return std::nullopt; sawSfx = true; }
            else if (key == "music") { if (!parseFloat(value, parsed.music)) return std::nullopt; sawMusic = true; }
            else if (key == "ambience") { if (!parseFloat(value, parsed.ambience)) return std::nullopt; sawAmbience = true; }
            else if (key == "enabled") {
                if (value != "0" && value != "1") return std::nullopt;
                parsed.enabled = value == "1";
                sawEnabled = true;
            }
        }
        if (!(sawMaster && sawSfx && sawMusic && sawAmbience && sawEnabled)) return std::nullopt;
        return AudioSettings{parsed};
    } catch (...) {
        return std::nullopt;
    }
}

float AudioSettings::sanitizeLevel(float value) noexcept {
    if (!std::isfinite(value)) return 0.0F;
    return std::clamp(value, 0.0F, 1.0F);
}

} // namespace kyrevex::audio
