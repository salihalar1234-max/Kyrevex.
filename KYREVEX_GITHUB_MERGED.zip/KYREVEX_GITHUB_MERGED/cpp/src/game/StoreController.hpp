#pragma once

#include "StoreScreenModel.hpp"

#include <cstdint>

namespace kyrevex::economy {

struct StoreAction {
    ActionResult result{};
    StoreScreenModel screen{};
    std::uint64_t revision{0};
};

// Game-thread controller between touch/UI events and the deterministic economy
// rules. The renderer reads screen(); it never mutates PlayerEconomy directly.
class StoreController final {
public:
    explicit StoreController(PlayerEconomy& player,
                             Language language = Language::Arabic) noexcept;

    [[nodiscard]] const StoreScreenModel& open() noexcept;
    [[nodiscard]] const StoreScreenModel& screen() const noexcept { return screen_; }
    [[nodiscard]] std::uint64_t revision() const noexcept { return revision_; }
    [[nodiscard]] bool setLanguage(Language language) noexcept;

    [[nodiscard]] StoreAction activate(OfferId id) noexcept;
    [[nodiscard]] StoreAction usePotion() noexcept;
    [[nodiscard]] StoreAction craftPotion() noexcept;
    [[nodiscard]] StoreAction craftTrailRation() noexcept;
    [[nodiscard]] StoreAction useTrailRation() noexcept;
    [[nodiscard]] StoreAction craftRune() noexcept;
    [[nodiscard]] StoreAction upgradeInfusion() noexcept;

private:
    [[nodiscard]] StoreAction finish(ActionResult result) noexcept;
    void rebuild() noexcept;

    PlayerEconomy* player_{nullptr};
    Language language_{Language::Arabic};
    StoreScreenModel screen_{};
    std::uint64_t revision_{0};
};

} // namespace kyrevex::economy
