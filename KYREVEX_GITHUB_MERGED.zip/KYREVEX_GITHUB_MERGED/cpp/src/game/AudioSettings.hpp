#pragma once

#include <atomic>
#include <optional>
#include <string>
#include <string_view>

namespace kyrevex::audio {

enum class Bus { Sfx, Music, Ambience };

struct AudioSettingsState {
    float master{0.92F};
    float sfx{0.82F};
    float music{0.30F};
    float ambience{0.24F};
    bool enabled{true};
};

struct AudioRuntimeState {
    bool appVisible{true};
    bool audioFocusGranted{true};
    bool gamePaused{false};
};

struct AudioMix {
    float master{0.0F};
    float sfx{0.0F};
    float music{0.0F};
    float ambience{0.0F};
    float echoWet{0.0F};
};

// Platform-neutral output contract. Android's Oboe/OpenSL ES adapter can
// implement this interface without leaking platform types into game rules.
class AudioOutput {
public:
    virtual ~AudioOutput() = default;
    virtual void apply(const AudioMix& mix, float rampSeconds) noexcept = 0;
};

class AudioSettings final {
public:
    AudioSettings() = default;
    explicit AudioSettings(AudioSettingsState initial) noexcept;
    AudioSettings(const AudioSettings&) = delete;
    AudioSettings& operator=(const AudioSettings&) = delete;
    AudioSettings(AudioSettings&& other) noexcept;
    AudioSettings& operator=(AudioSettings&& other) noexcept;

    [[nodiscard]] AudioSettingsState state() const noexcept;
    void setEnabled(bool enabled) noexcept;
    void setMaster(float value) noexcept;
    void setBusLevel(Bus bus, float value) noexcept;

    [[nodiscard]] AudioMix mix(const AudioRuntimeState& runtime = {}) const noexcept;
    void apply(AudioOutput& output,
               const AudioRuntimeState& runtime = {},
               float rampSeconds = 0.08F) const noexcept;

    // Versioned, dependency-free text format suitable for SharedPreferences,
    // Android DataStore, or a native save adapter.
    [[nodiscard]] std::string serialize() const;
    [[nodiscard]] static std::optional<AudioSettings> deserialize(std::string_view data) noexcept;

    [[nodiscard]] static float sanitizeLevel(float value) noexcept;

private:
    // Atomic scalar controls let the Android audio callback read gains without
    // taking a mutex while the settings UI updates sliders on another thread.
    std::atomic<float> master_{0.92F};
    std::atomic<float> sfx_{0.82F};
    std::atomic<float> music_{0.30F};
    std::atomic<float> ambience_{0.24F};
    std::atomic<bool> enabled_{true};
};

} // namespace kyrevex::audio
