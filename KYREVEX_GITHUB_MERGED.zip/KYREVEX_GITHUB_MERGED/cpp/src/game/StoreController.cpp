#include "StoreController.hpp"

namespace kyrevex::economy {

StoreController::StoreController(PlayerEconomy& player, Language language) noexcept
    : player_(&player), language_(language) {
    rebuild();
}

const StoreScreenModel& StoreController::open() noexcept {
    rebuild();
    return screen_;
}

bool StoreController::setLanguage(Language language) noexcept {
    if (static_cast<std::size_t>(language) >= 3) return false;
    if (language_ != language) {
        language_ = language;
        rebuild();
    }
    return true;
}

void StoreController::rebuild() noexcept {
    screen_ = player_ == nullptr ? StoreScreenModel{} : StoreScreenPresenter::build(*player_, language_);
    ++revision_;
}

StoreAction StoreController::finish(ActionResult result) noexcept {
    rebuild();
    return StoreAction{result, screen_, revision_};
}

StoreAction StoreController::activate(OfferId id) noexcept {
    if (player_ == nullptr) return finish(ActionResult{ResultCode::InvalidState});
    return finish(StoreSystem::purchase(*player_, id));
}

StoreAction StoreController::usePotion() noexcept {
    if (player_ == nullptr) return finish(ActionResult{ResultCode::InvalidState});
    return finish(StoreSystem::usePotion(*player_));
}

StoreAction StoreController::craftPotion() noexcept {
    if (player_ == nullptr) return finish(ActionResult{ResultCode::InvalidState});
    return finish(StoreSystem::craftPotion(*player_));
}

StoreAction StoreController::craftTrailRation() noexcept {
    if (player_ == nullptr) return finish(ActionResult{ResultCode::InvalidState});
    return finish(StoreSystem::craftTrailRation(*player_));
}

StoreAction StoreController::useTrailRation() noexcept {
    if (player_ == nullptr) return finish(ActionResult{ResultCode::InvalidState});
    return finish(StoreSystem::useTrailRation(*player_));
}

StoreAction StoreController::craftRune() noexcept {
    if (player_ == nullptr) return finish(ActionResult{ResultCode::InvalidState});
    return finish(StoreSystem::craftRune(*player_));
}

StoreAction StoreController::upgradeInfusion() noexcept {
    if (player_ == nullptr) return finish(ActionResult{ResultCode::InvalidState});
    return finish(StoreSystem::upgradeInfusion(*player_));
}

} // namespace kyrevex::economy
