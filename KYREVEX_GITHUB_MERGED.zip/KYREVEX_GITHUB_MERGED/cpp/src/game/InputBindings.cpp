#include "game/InputBindings.hpp"

#include <sstream>

namespace kyrevex::input {

bool InputBindings::validSource(Source source) noexcept {
    return source == Source::Keyboard || source == Source::Touch || source == Source::Gamepad;
}

bool InputBindings::validAction(Action action) noexcept {
    return static_cast<std::size_t>(action) < kActionCount;
}

InputBindings InputBindings::defaults() noexcept {
    InputBindings map;
    (void)map.bind(Source::Keyboard, static_cast<std::uint32_t>(HidKey::W), Action::MoveUp);
    (void)map.bind(Source::Keyboard, static_cast<std::uint32_t>(HidKey::S), Action::MoveDown);
    (void)map.bind(Source::Keyboard, static_cast<std::uint32_t>(HidKey::A), Action::MoveLeft);
    (void)map.bind(Source::Keyboard, static_cast<std::uint32_t>(HidKey::D), Action::MoveRight);
    (void)map.bind(Source::Keyboard, static_cast<std::uint32_t>(HidKey::Space), Action::Attack);
    (void)map.bind(Source::Keyboard, static_cast<std::uint32_t>(HidKey::X), Action::HeavyAttack);
    (void)map.bind(Source::Keyboard, static_cast<std::uint32_t>(HidKey::J), Action::Jump);
    (void)map.bind(Source::Keyboard, static_cast<std::uint32_t>(HidKey::C), Action::Guard);
    (void)map.bind(Source::Keyboard, static_cast<std::uint32_t>(HidKey::F), Action::TargetLock);
    (void)map.bind(Source::Keyboard, static_cast<std::uint32_t>(HidKey::Q), Action::Skill);
    (void)map.bind(Source::Keyboard, static_cast<std::uint32_t>(HidKey::LeftShift), Action::Dash);
    (void)map.bind(Source::Keyboard, static_cast<std::uint32_t>(HidKey::E), Action::Interact);
    (void)map.bind(Source::Keyboard, static_cast<std::uint32_t>(HidKey::LeftAlt), Action::Sprint);
    (void)map.bind(Source::Keyboard, static_cast<std::uint32_t>(HidKey::Escape), Action::Pause);
    (void)map.bind(Source::Keyboard, static_cast<std::uint32_t>(HidKey::M), Action::OpenMap);
    (void)map.bind(Source::Keyboard, static_cast<std::uint32_t>(HidKey::I), Action::OpenInventory);
    return map;
}

bool InputBindings::bind(Source source, std::uint32_t controlId, Action action) noexcept {
    if (!validSource(source) || !validAction(action)) {
        return false;
    }
    Slot* freeSlot = nullptr;
    for (auto& slot : slots_) {
        if (slot.active && slot.binding.source == source && slot.binding.controlId == controlId) {
            slot.binding.action = action;
            return true;
        }
        if (!slot.active && freeSlot == nullptr) {
            freeSlot = &slot;
        }
    }
    if (freeSlot == nullptr) {
        return false;
    }
    freeSlot->active = true;
    freeSlot->binding = Binding{source, controlId, action};
    ++size_;
    return true;
}

bool InputBindings::unbind(Source source, std::uint32_t controlId) noexcept {
    if (!validSource(source)) {
        return false;
    }
    for (auto& slot : slots_) {
        if (slot.active && slot.binding.source == source && slot.binding.controlId == controlId) {
            slot.active = false;
            --size_;
            return true;
        }
    }
    return false;
}

std::optional<Action> InputBindings::actionFor(Source source,
                                                std::uint32_t controlId) const noexcept {
    if (!validSource(source)) {
        return std::nullopt;
    }
    for (const auto& slot : slots_) {
        if (slot.active && slot.binding.source == source && slot.binding.controlId == controlId) {
            return slot.binding.action;
        }
    }
    return std::nullopt;
}

std::string InputBindings::serialize() const {
    std::ostringstream output;
    output << "KYREVEX_INPUT_BINDINGS 1\n";
    output << "count " << size_ << '\n';
    for (const auto& slot : slots_) {
        if (!slot.active) {
            continue;
        }
        output << "binding " << static_cast<unsigned>(slot.binding.source) << ' '
               << slot.binding.controlId << ' '
               << static_cast<unsigned>(slot.binding.action) << '\n';
    }
    return output.str();
}

std::optional<InputBindings> InputBindings::deserialize(std::string_view data) {
    std::istringstream input{std::string(data)};
    std::string magic;
    unsigned version = 0;
    std::string countLabel;
    std::size_t count = 0;
    if (!(input >> magic >> version) || magic != "KYREVEX_INPUT_BINDINGS" || version != 1U ||
        !(input >> countLabel >> count) || countLabel != "count" || count > kMaxBindings) {
        return std::nullopt;
    }

    InputBindings result;
    for (std::size_t i = 0; i < count; ++i) {
        std::string record;
        unsigned sourceValue = 0;
        std::uint32_t controlId = 0;
        unsigned actionValue = 0;
        if (!(input >> record >> sourceValue >> controlId >> actionValue) || record != "binding" ||
            sourceValue > static_cast<unsigned>(Source::Gamepad) ||
            actionValue >= static_cast<unsigned>(Action::Count)) {
            return std::nullopt;
        }
        const auto source = static_cast<Source>(sourceValue);
        const auto action = static_cast<Action>(actionValue);
        if (result.actionFor(source, controlId).has_value() ||
            !result.bind(source, controlId, action)) {
            return std::nullopt;
        }
    }

    std::string trailing;
    if (input >> trailing) {
        return std::nullopt;
    }
    return result;
}

} // namespace kyrevex::input
