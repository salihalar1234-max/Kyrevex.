#pragma once

#include <array>
#include <cstdint>
#include <optional>
#include <string>
#include <string_view>

namespace kyrevex::economy {

enum class Language { Arabic, English, Turkish };
enum class Appearance : std::uint8_t { Emerald, Crimson, Violet, Count };
enum class OfferId : std::uint8_t {
    Potion, PotionPack, Herbs, HerbBundle, Essence, EssencePack, Ration,
    BladeUpgrade, ArmorUpgrade, CrimsonCloak, VioletCloak, Count
};

enum class ResultCode : std::uint8_t {
    Success, EquippedExisting, AlreadyEquipped, UnknownOffer, InsufficientCoins,
    InventoryFull, MaxTier, InsufficientResources, RankRequired, NoConsumable,
    HealthFull, InvalidState
};

struct PlayerEconomy {
    std::int64_t coins{120};
    int potions{2};
    int herbs{2};
    int essence{0};
    int trailRations{0};
    int swordTier{0};
    int armorTier{0};
    int runeTier{0};
    int infusionTier{0};
    int veilReputation{0};
    int hp{100};
    int maxHp{100};
    int energy{100};
    int maxEnergy{100};
    int damage{12};
    float criticalChance{0.05F};
    std::array<bool, static_cast<std::size_t>(Appearance::Count)> ownedAppearances{true, false, false};
    Appearance equippedAppearance{Appearance::Emerald};
};

struct OfferDefinition {
    OfferId id;
    std::string_view key;
    std::string_view icon;
    std::array<std::string_view, 3> name;
    std::array<std::string_view, 3> description;
};

struct ActionResult {
    ResultCode code{ResultCode::InvalidState};
    std::int64_t coinsSpent{0};
    int primaryAmount{0};
    int secondaryAmount{0};
    int bonusXp{0};
    [[nodiscard]] bool succeeded() const noexcept {
        return code == ResultCode::Success || code == ResultCode::EquippedExisting;
    }
};

struct OfferState {
    OfferId id{OfferId::Potion};
    std::int64_t price{0};
    int owned{0};
    int cap{0};
    bool canBuy{false};
    bool alreadyOwned{false};
    ResultCode blockedBy{ResultCode::Success};
};

class StoreSystem final {
public:
    [[nodiscard]] static const std::array<OfferDefinition, static_cast<std::size_t>(OfferId::Count)>& catalog() noexcept;
    [[nodiscard]] static std::int64_t price(const PlayerEconomy& player, OfferId id) noexcept;
    [[nodiscard]] static OfferState inspect(const PlayerEconomy& player, OfferId id) noexcept;
    [[nodiscard]] static ActionResult purchase(PlayerEconomy& player, OfferId id) noexcept;

    [[nodiscard]] static ActionResult usePotion(PlayerEconomy& player) noexcept;
    [[nodiscard]] static ActionResult craftPotion(PlayerEconomy& player) noexcept;
    [[nodiscard]] static ActionResult craftTrailRation(PlayerEconomy& player) noexcept;
    [[nodiscard]] static ActionResult useTrailRation(PlayerEconomy& player) noexcept;
    [[nodiscard]] static ActionResult craftRune(PlayerEconomy& player) noexcept;
    [[nodiscard]] static ActionResult upgradeInfusion(PlayerEconomy& player) noexcept;

    [[nodiscard]] static bool isValid(const PlayerEconomy& player) noexcept;
    [[nodiscard]] static std::string serializePlayer(const PlayerEconomy& player);
    [[nodiscard]] static std::optional<PlayerEconomy> deserializePlayer(std::string_view data) noexcept;
    [[nodiscard]] static std::string_view localizedName(OfferId id, Language language) noexcept;

private:
    [[nodiscard]] static ActionResult failure(ResultCode code) noexcept;
};

} // namespace kyrevex::economy
