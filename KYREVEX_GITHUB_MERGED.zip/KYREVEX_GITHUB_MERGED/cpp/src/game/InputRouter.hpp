#pragma once

#include <array>
#include <cstddef>
#include <cstdint>

namespace kyrevex::input {

enum class Action : std::uint8_t {
    MoveUp = 0,
    MoveDown,
    MoveLeft,
    MoveRight,
    Attack,
    HeavyAttack,
    Jump,
    Guard,
    TargetLock,
    Skill,
    Dash,
    Interact,
    Sprint,
    Pause,
    OpenMap,
    OpenInventory,
    Count
};

enum class Source : std::uint8_t {
    Keyboard = 0,
    Touch,
    Gamepad
};

inline constexpr std::size_t kActionCount = static_cast<std::size_t>(Action::Count);

struct InputSnapshot final {
    std::array<bool, kActionCount> down{};
    std::array<bool, kActionCount> pressed{};
    std::array<bool, kActionCount> released{};
    float moveX{0.0F};
    float moveY{0.0F};
    float moveMagnitude{0.0F};

    [[nodiscard]] bool isDown(Action action) const noexcept;
    [[nodiscard]] bool wasPressed(Action action) const noexcept;
    [[nodiscard]] bool wasReleased(Action action) const noexcept;
};

// A small, allocation-free action router shared by keyboard, touch and gamepad input.
// Call its event methods and advanceFrame() on the game/application thread.
class InputRouter final {
public:
    static constexpr std::size_t kMaxButtons = 64;
    static constexpr std::size_t kMaxMoveAxes = 8;
    static constexpr float kDefaultDeadzone = 0.18F;

    InputRouter() noexcept = default;

    // controlId identifies a key, pointer/button, or gamepad button within its source.
    // Repeated down events for an existing source/control pair are idempotent.
    [[nodiscard]] bool setButton(Source source, std::uint32_t controlId,
                                 Action action, bool isDown) noexcept;

    // Use a stable controlId for each analog stick/pointer. Values are clamped to [-1, 1].
    [[nodiscard]] bool setMoveAxis(Source source, std::uint32_t controlId,
                                   float x, float y) noexcept;
    [[nodiscard]] bool releaseMoveAxis(Source source, std::uint32_t controlId) noexcept;

    // Releases both button and axis state for one control, or every control from a source.
    void releaseControl(Source source, std::uint32_t controlId) noexcept;
    void releaseSource(Source source) noexcept;
    void focusLost() noexcept;

    void setDeadzone(float deadzone) noexcept;
    [[nodiscard]] float deadzone() const noexcept { return deadzone_; }

    // Call exactly once per frame after collecting that frame's input events.
    // The returned snapshot contains held state and one-frame pressed/released edges.
    [[nodiscard]] const InputSnapshot& advanceFrame() noexcept;
    [[nodiscard]] const InputSnapshot& snapshot() const noexcept { return snapshot_; }

private:
    struct ButtonSlot final {
        bool active{false};
        Source source{Source::Keyboard};
        std::uint32_t controlId{0};
        Action action{Action::Attack};
    };

    struct AxisSlot final {
        bool active{false};
        Source source{Source::Keyboard};
        std::uint32_t controlId{0};
        float x{0.0F};
        float y{0.0F};
    };

    [[nodiscard]] static bool validSource(Source source) noexcept;
    [[nodiscard]] static bool validAction(Action action) noexcept;
    [[nodiscard]] static float finiteClamp(float value) noexcept;
    [[nodiscard]] static std::size_t indexOf(Action action) noexcept;

    std::array<ButtonSlot, kMaxButtons> buttons_{};
    std::array<AxisSlot, kMaxMoveAxes> axes_{};
    InputSnapshot snapshot_{};
    float deadzone_{kDefaultDeadzone};
};

} // namespace kyrevex::input
