#pragma once

#include "AudioEngine.hpp"

#include <cstdint>

namespace kyrevex::audio {

enum class BuiltinClip : ClipId {
    UiConfirm = 1,
    SwordSlash = 2,
    AetherCast = 3,
    PlayerHit = 4,
    Footstep = 5,
    MusicLoop = 10,
    WorldAmbienceLoop = 11
};

struct BuiltinAudioConfig {
    std::uint32_t effectsRate{48000};
    std::uint32_t loopRate{22050};
    std::uint32_t loopSeconds{12};
};

class BuiltinAudioAssets final {
public:
    // Generates original procedural PCM outside the real-time callback.
    // This provides a playable default soundscape without third-party media.
    [[nodiscard]] static bool install(AudioEngine& engine,
                                      BuiltinAudioConfig config = {}) noexcept;
    [[nodiscard]] static bool startBackgroundLoops(AudioEngine& engine) noexcept;
    [[nodiscard]] static bool play(AudioEngine& engine, BuiltinClip clip,
                                   float gain = 1.0F) noexcept;
};

} // namespace kyrevex::audio
