#include "game/TouchControlLayout.hpp"

#include <algorithm>
#include <cmath>
#include <iomanip>
#include <sstream>

namespace kyrevex::input {

bool TouchControlLayout::validId(TouchControlId id) noexcept {
    return static_cast<std::size_t>(id) < kTouchControlCount;
}

std::size_t TouchControlLayout::indexOf(TouchControlId id) noexcept {
    return static_cast<std::size_t>(id);
}

bool TouchControlLayout::validPlacement(const TouchControlPlacement& placement) noexcept {
    if (!std::isfinite(placement.x) || !std::isfinite(placement.y) ||
        !std::isfinite(placement.size) || !std::isfinite(placement.opacity)) {
        return false;
    }
    if (placement.size < kMinSize || placement.size > kMaxSize ||
        placement.opacity < 0.0F || placement.opacity > 1.0F) {
        return false;
    }
    const float radius = placement.size * 0.5F;
    return placement.x >= radius && placement.x <= (1.0F - radius) &&
           placement.y >= radius && placement.y <= (1.0F - radius);
}

void TouchControlLayout::constrainPosition(TouchControlPlacement& placement) noexcept {
    const float radius = placement.size * 0.5F;
    placement.x = std::clamp(placement.x, radius, 1.0F - radius);
    placement.y = std::clamp(placement.y, radius, 1.0F - radius);
}

TouchControlLayout TouchControlLayout::defaults() noexcept {
    TouchControlLayout layout;
    layout.controls_ = {{
        {0.15F, 0.77F, 0.21F, 0.80F, true},  // Movement stick
        {0.87F, 0.75F, 0.17F, 0.95F, true},  // Attack
        {0.72F, 0.86F, 0.13F, 0.90F, true},  // Heavy attack
        {0.91F, 0.53F, 0.12F, 0.86F, true},  // Jump
        {0.75F, 0.60F, 0.12F, 0.88F, true},  // Guard
        {0.60F, 0.72F, 0.10F, 0.76F, true},  // Target lock
        {0.59F, 0.88F, 0.12F, 0.90F, true},  // Skill
        {0.43F, 0.88F, 0.11F, 0.84F, true},  // Dash
        {0.47F, 0.68F, 0.105F, 0.84F, true}, // Interact
        {0.25F, 0.55F, 0.10F, 0.72F, true},  // Sprint
        {0.93F, 0.11F, 0.085F, 0.75F, true}, // Map
        {0.82F, 0.11F, 0.085F, 0.75F, true}  // Menu
    }};
    return layout;
}

const TouchControlPlacement* TouchControlLayout::get(TouchControlId id) const noexcept {
    return validId(id) ? &controls_[indexOf(id)] : nullptr;
}

bool TouchControlLayout::setPosition(TouchControlId id, float x, float y) noexcept {
    if (!validId(id) || !std::isfinite(x) || !std::isfinite(y)) {
        return false;
    }
    auto& placement = controls_[indexOf(id)];
    placement.x = x;
    placement.y = y;
    constrainPosition(placement);
    return true;
}

bool TouchControlLayout::setSize(TouchControlId id, float size) noexcept {
    if (!validId(id) || !std::isfinite(size)) {
        return false;
    }
    auto& placement = controls_[indexOf(id)];
    placement.size = std::clamp(size, kMinSize, kMaxSize);
    constrainPosition(placement);
    return true;
}

bool TouchControlLayout::setOpacity(TouchControlId id, float opacity) noexcept {
    if (!validId(id) || !std::isfinite(opacity)) {
        return false;
    }
    controls_[indexOf(id)].opacity = std::clamp(opacity, 0.0F, 1.0F);
    return true;
}

bool TouchControlLayout::setVisible(TouchControlId id, bool visible) noexcept {
    if (!validId(id)) {
        return false;
    }
    controls_[indexOf(id)].visible = visible;
    return true;
}

void TouchControlLayout::setLeftHanded(bool enabled) noexcept {
    if (leftHanded_ == enabled) {
        return;
    }
    for (auto& placement : controls_) {
        placement.x = 1.0F - placement.x;
    }
    leftHanded_ = enabled;
}

std::string TouchControlLayout::serialize() const {
    std::ostringstream output;
    output << std::fixed << std::setprecision(6);
    output << "KYREVEX_TOUCH_LAYOUT 1\n";
    output << "left_handed " << (leftHanded_ ? 1 : 0) << '\n';
    output << "count " << kTouchControlCount << '\n';
    for (std::size_t i = 0; i < controls_.size(); ++i) {
        const auto& placement = controls_[i];
        output << "control " << i << ' ' << placement.x << ' ' << placement.y << ' '
               << placement.size << ' ' << placement.opacity << ' '
               << (placement.visible ? 1 : 0) << '\n';
    }
    return output.str();
}

std::optional<TouchControlLayout> TouchControlLayout::deserialize(std::string_view data) {
    std::istringstream input{std::string(data)};
    std::string magic;
    unsigned version = 0;
    std::string leftLabel;
    unsigned leftHanded = 0;
    std::string countLabel;
    std::size_t count = 0;
    if (!(input >> magic >> version) || magic != "KYREVEX_TOUCH_LAYOUT" || version != 1U ||
        !(input >> leftLabel >> leftHanded) || leftLabel != "left_handed" || leftHanded > 1U ||
        !(input >> countLabel >> count) || countLabel != "count" || count != kTouchControlCount) {
        return std::nullopt;
    }

    TouchControlLayout result = defaults();
    result.leftHanded_ = leftHanded == 1U;
    std::array<bool, kTouchControlCount> seen{};
    for (std::size_t i = 0; i < count; ++i) {
        std::string record;
        std::size_t id = 0;
        TouchControlPlacement placement{};
        unsigned visible = 0;
        if (!(input >> record >> id >> placement.x >> placement.y >> placement.size >>
              placement.opacity >> visible) || record != "control" || id >= kTouchControlCount ||
            visible > 1U || seen[id]) {
            return std::nullopt;
        }
        placement.visible = visible == 1U;
        if (!validPlacement(placement)) {
            return std::nullopt;
        }
        result.controls_[id] = placement;
        seen[id] = true;
    }

    std::string trailing;
    if (input >> trailing) {
        return std::nullopt;
    }
    for (const bool present : seen) {
        if (!present) {
            return std::nullopt;
        }
    }
    return result;
}

} // namespace kyrevex::input
