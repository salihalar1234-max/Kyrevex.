#include "game/AudioSettings.hpp"
#include "game/AudioEngine.hpp"
#include "game/BuiltinAudioAssets.hpp"
#include "game/StoreSystem.hpp"
#include "game/StoreScreenModel.hpp"
#include "game/StoreController.hpp"
#include "game/InputRouter.hpp"
#include "game/InputBindings.hpp"
#include "game/TouchControlLayout.hpp"

#include <algorithm>
#include <bit>
#include <cmath>
#include <cstring>
#include <cstdlib>
#include <iostream>
#include <limits>
#include <string>
#include <cstdint>
#include <vector>

namespace {
int checks = 0;
int failures = 0;

void check(bool condition, const char* label) {
    ++checks;
    if (!condition) {
        ++failures;
        std::cerr << "FAIL: " << label << '\n';
    }
}

bool near(float a, float b, float epsilon = 0.0001F) {
    return std::fabs(a - b) <= epsilon;
}

struct RecordingOutput final : kyrevex::audio::AudioOutput {
    kyrevex::audio::AudioMix last{};
    float ramp{-1.0F};
    int calls{0};
    void apply(const kyrevex::audio::AudioMix& mix, float seconds) noexcept override {
        last = mix;
        ramp = seconds;
        ++calls;
    }
};

void audioTests() {
    using namespace kyrevex::audio;
    AudioSettings settings;
    const auto defaults = settings.state();
    check(near(defaults.master, 0.92F), "audio default master follows V3.60");
    check(near(defaults.sfx, 0.82F), "audio default SFX follows V3.60");
    check(near(defaults.music, 0.30F), "audio default music follows V3.60");
    check(near(defaults.ambience, 0.24F), "audio default ambience follows V3.60");

    settings.setMaster(1.5F);
    settings.setBusLevel(Bus::Sfx, -0.2F);
    settings.setBusLevel(Bus::Music, std::numeric_limits<float>::quiet_NaN());
    settings.setBusLevel(Bus::Ambience, 0.63F);
    auto clamped = settings.state();
    check(near(clamped.master, 1.0F), "master level clamps to one");
    check(near(clamped.sfx, 0.0F), "negative SFX level clamps to zero");
    check(near(clamped.music, 0.0F), "non-finite music level safely mutes");
    check(near(clamped.ambience, 0.63F), "valid ambience level retained");

    const std::string encoded = settings.serialize();
    const auto restored = AudioSettings::deserialize(encoded);
    check(restored.has_value(), "audio settings round-trip parses");
    if (restored) {
        const auto state = restored->state();
        check(near(state.master, 1.0F) && near(state.sfx, 0.0F) && near(state.music, 0.0F),
              "audio settings round-trip keeps bus levels");
        check(near(state.ambience, 0.63F) && state.enabled, "audio settings round-trip keeps enabled flag");
    }
    check(!AudioSettings::deserialize("NOT_KYREVEX 1\n"), "audio rejects unknown schema");
    check(!AudioSettings::deserialize("KYREVEX_AUDIO_SETTINGS 1\nmaster 1\n"),
          "audio rejects incomplete settings");
    check(!AudioSettings::deserialize("KYREVEX_AUDIO_SETTINGS 2\n"), "audio rejects future schema");

    settings.setEnabled(false);
    auto muted = settings.mix();
    check(near(muted.master, 0.0F) && near(muted.echoWet, 0.0F), "global mute disables audio output");
    settings.setEnabled(true);
    auto normal = settings.mix();
    check(near(normal.master, 1.0F) && near(normal.echoWet, 0.12F), "enabled output restores master and echo");
    auto noFocus = settings.mix(AudioRuntimeState{true, false, false});
    check(near(noFocus.master, 0.0F), "audio focus loss silences output");
    auto hidden = settings.mix(AudioRuntimeState{false, true, false});
    check(near(hidden.master, 0.0F), "backgrounded app silences output");
    auto paused = settings.mix(AudioRuntimeState{true, true, true});
    check(near(paused.music, settings.state().music * 0.45F), "pause ducks music bus");
    check(near(paused.ambience, settings.state().ambience * 0.30F), "pause ducks ambience bus");
    check(near(paused.sfx, settings.state().sfx), "pause retains UI SFX level");

    RecordingOutput output;
    settings.apply(output, {}, 9.0F);
    check(output.calls == 1 && near(output.ramp, 2.0F), "audio adapter receives bounded ramp time");
    settings.apply(output, {}, std::numeric_limits<float>::quiet_NaN());
    check(near(output.ramp, 0.08F), "invalid ramp uses safe default");
}


std::vector<std::uint8_t> makeMonoPcm16Wav(const std::array<std::int16_t, 4>& samples,
                                           std::uint32_t sampleRate = 48000) {
    std::vector<std::uint8_t> bytes(44 + samples.size() * 2, 0);
    const auto put16 = [&bytes](std::size_t p, std::uint16_t v) {
        bytes[p] = static_cast<std::uint8_t>(v & 0xffU);
        bytes[p + 1] = static_cast<std::uint8_t>((v >> 8U) & 0xffU);
    };
    const auto put32 = [&bytes](std::size_t p, std::uint32_t v) {
        bytes[p] = static_cast<std::uint8_t>(v & 0xffU);
        bytes[p + 1] = static_cast<std::uint8_t>((v >> 8U) & 0xffU);
        bytes[p + 2] = static_cast<std::uint8_t>((v >> 16U) & 0xffU);
        bytes[p + 3] = static_cast<std::uint8_t>((v >> 24U) & 0xffU);
    };
    std::memcpy(bytes.data(), "RIFF", 4);
    put32(4, static_cast<std::uint32_t>(bytes.size() - 8));
    std::memcpy(bytes.data() + 8, "WAVEfmt ", 8);
    put32(16, 16); put16(20, 1); put16(22, 1); put32(24, sampleRate);
    put32(28, sampleRate * 2); put16(32, 2); put16(34, 16);
    std::memcpy(bytes.data() + 36, "data", 4);
    put32(40, static_cast<std::uint32_t>(samples.size() * 2));
    for (std::size_t i = 0; i < samples.size(); ++i) put16(44 + i * 2, static_cast<std::uint16_t>(samples[i]));
    return bytes;
}

std::vector<std::uint8_t> makeMonoFloatWav(float sample) {
    std::vector<std::uint8_t> bytes(48, 0);
    const auto put16 = [&bytes](std::size_t p, std::uint16_t v) {
        bytes[p] = static_cast<std::uint8_t>(v & 0xffU);
        bytes[p + 1] = static_cast<std::uint8_t>((v >> 8U) & 0xffU);
    };
    const auto put32 = [&bytes](std::size_t p, std::uint32_t v) {
        bytes[p] = static_cast<std::uint8_t>(v & 0xffU);
        bytes[p + 1] = static_cast<std::uint8_t>((v >> 8U) & 0xffU);
        bytes[p + 2] = static_cast<std::uint8_t>((v >> 16U) & 0xffU);
        bytes[p + 3] = static_cast<std::uint8_t>((v >> 24U) & 0xffU);
    };
    std::memcpy(bytes.data(), "RIFF", 4); put32(4, 40);
    std::memcpy(bytes.data() + 8, "WAVEfmt ", 8);
    put32(16, 16); put16(20, 3); put16(22, 1); put32(24, 48000);
    put32(28, 192000); put16(32, 4); put16(34, 32);
    std::memcpy(bytes.data() + 36, "data", 4); put32(40, 4);
    put32(44, std::bit_cast<std::uint32_t>(sample));
    return bytes;
}

void audioEngineTests() {
    using namespace kyrevex::audio;
    const auto wav = makeMonoPcm16Wav({8192, 16384, -8192, 0});
    const auto clip = PcmClip::fromWav(wav);
    check(clip.valid() && clip.frames() == 4 && clip.channels == 1,
          "PCM WAV loader parses a valid mono PCM16 clip");
    check(near(clip.samples[0], 0.25F, 0.0001F) && near(clip.samples[1], 0.5F, 0.0001F),
          "PCM WAV loader converts signed 16-bit samples to normalized float");

    auto corrupt = wav;
    corrupt[0] = 'X';
    check(!PcmClip::fromWav(corrupt).valid(), "PCM WAV loader rejects invalid RIFF header");
    check(!PcmClip::fromWav(wav, 2).valid(), "PCM WAV loader enforces caller frame budget");
    const auto floatWav = PcmClip::fromWav(makeMonoFloatWav(0.375F));
    check(floatWav.valid() && floatWav.frames() == 1 && near(floatWav.samples[0], 0.375F),
          "PCM WAV loader accepts IEEE Float32 clips");
    const auto nanWav = PcmClip::fromWav(makeMonoFloatWav(std::numeric_limits<float>::quiet_NaN()));
    check(nanWav.valid() && near(nanWav.samples[0], 0.0F),
          "PCM WAV loader sanitizes non-finite float samples");

    AudioEngine engine;
    check(engine.registerClip(10, clip), "audio engine registers clip before sealing");
    check(!engine.registerClip(10, clip), "audio engine rejects duplicate clip IDs");
    check(engine.sealAssets(), "audio engine seals immutable clip bank");
    check(!engine.registerClip(11, clip), "audio engine refuses asset mutation after sealing");

    AudioMix mix{};
    mix.master = 1.0F; mix.sfx = 1.0F; mix.music = 1.0F; mix.ambience = 1.0F;
    engine.apply(mix, 0.0F);
    check(engine.play(10, Bus::Sfx, 1.0F, false), "audio engine accepts valid SFX play command");
    std::array<float, 8> output{};
    engine.render(output.data(), 4, 2);
    check(near(output[0], 0.25F * 0.85F, 0.001F) && near(output[1], output[0]),
          "audio engine renders mono PCM to stereo with configured bus gain");
    check(engine.stats().renderedFrames == 4 && engine.stats().activeVoices == 0,
          "one-shot voice completes and render statistics update");

    check(engine.play(10, Bus::Ambience, 0.5F, true), "audio engine accepts looping ambience");
    std::vector<float> loopOutput(960, 0.0F);
    engine.render(loopOutput.data(), 8, 2);
    check(engine.stats().activeVoices == 1, "looping voice wraps and remains active");
    check(engine.stopBus(Bus::Ambience), "audio engine queues stop for an audio bus");
    engine.render(loopOutput.data(), 2, 2);
    check(engine.stats().activeVoices == 0, "bus stop command releases matching voices");

    check(engine.play(10, Bus::Music, 1.0F, true), "audio engine starts music loop");
    engine.apply(AudioMix{0.0F, 1.0F, 1.0F, 1.0F, 0.0F}, 0.01F);
    engine.render(loopOutput.data(), 480, 2);
    check(std::fabs(loopOutput[958]) < 0.00001F && std::fabs(loopOutput[959]) < 0.00001F,
          "audio engine master ramp reaches global mute without an abrupt step");
    check(engine.stopAll(), "audio engine queues stop-all command");
    engine.render(loopOutput.data(), 2, 2);
    check(engine.stats().activeVoices == 0, "stop-all releases every voice");

    AudioEngine queueEngine;
    check(queueEngine.registerClip(7, clip) && queueEngine.sealAssets(),
          "audio command queue test prepares a clip bank");
    std::size_t accepted = 0;
    for (std::size_t i = 0; i < AudioEngine::CommandCapacity + 3; ++i) {
        if (queueEngine.play(7, Bus::Sfx)) ++accepted;
    }
    check(accepted == AudioEngine::CommandCapacity &&
          queueEngine.stats().droppedCommands == 3,
          "audio command queue is bounded and counts overflow safely");
    queueEngine.render(output.data(), 4, 2);
    check(queueEngine.stats().activeVoices <= AudioEngine::MaxVoices,
          "audio voice pool remains bounded after queued commands");

    AudioEngine noAssets;
    check(!noAssets.sealAssets(), "audio engine refuses to seal an empty asset bank");
    check(!noAssets.play(1, Bus::Sfx), "audio engine rejects playback before assets are sealed");
}


void builtinAudioTests() {
    using namespace kyrevex::audio;
    AudioEngine engine;
    check(BuiltinAudioAssets::install(engine, BuiltinAudioConfig{48000, 22050, 6}),
          "builtin procedural audio installs full soundscape");
    check(engine.assetsSealed() && engine.hasClip(static_cast<ClipId>(BuiltinClip::SwordSlash)) &&
          engine.hasClip(static_cast<ClipId>(BuiltinClip::MusicLoop)),
          "builtin soundscape includes combat and background clips");
    check(BuiltinAudioAssets::startBackgroundLoops(engine),
          "builtin audio starts separate music and ambience loops");
    check(BuiltinAudioAssets::play(engine, BuiltinClip::AetherCast, 0.85F),
          "builtin audio triggers original aether skill sound");
    std::vector<float> output(512 * 2, 0.0F);
    engine.apply(AudioMix{0.85F, 0.82F, 0.30F, 0.24F, 0.0F}, 0.0F);
    engine.render(output.data(), 512, 2);
    check(std::any_of(output.begin(), output.end(), [](float v) { return std::fabs(v) > 0.0001F; }),
          "builtin soundscape generates non-silent PCM output");
    check(engine.stats().activeVoices >= 3,
          "builtin music, ambience and skill sound run as independent voices");

    AudioEngine invalid;
    check(!BuiltinAudioAssets::install(invalid, BuiltinAudioConfig{1000, 22050, 12}),
          "builtin audio rejects unsupported effect sample rate");
    check(!BuiltinAudioAssets::install(invalid, BuiltinAudioConfig{48000, 22050, 2}),
          "builtin audio rejects too-short seamless loop configuration");
}

void storeTests() {
    using namespace kyrevex::economy;
    PlayerEconomy p;
    check(StoreSystem::isValid(p), "default player economy is valid");
    check(StoreSystem::catalog().size() == 11, "store contains eleven V3.60 offers");
    check(StoreSystem::price(p, OfferId::Potion) == 35, "potion price matches V3.60");
    check(StoreSystem::price(p, OfferId::PotionPack) == 88, "potion pack price matches V3.60");
    check(StoreSystem::price(p, OfferId::Herbs) == 48, "herb price matches V3.60");
    check(StoreSystem::price(p, OfferId::EssencePack) == 245, "essence pack price matches V3.60");
    check(StoreSystem::localizedName(OfferId::Ration, Language::Turkish) == "Yol Azığı",
          "store labels provide Turkish localization");

    p.coins = 34;
    const auto before = p;
    const auto poor = StoreSystem::purchase(p, OfferId::Potion);
    check(poor.code == ResultCode::InsufficientCoins, "store rejects insufficient balance");
    check(p.coins == before.coins && p.potions == before.potions, "failed purchase is atomic");

    p.coins = 200;
    auto boughtPotion = StoreSystem::purchase(p, OfferId::Potion);
    check(boughtPotion.succeeded() && boughtPotion.coinsSpent == 35 && p.potions == 3,
          "store buys one potion and deducts exact price");
    auto pack = StoreSystem::purchase(p, OfferId::PotionPack);
    check(pack.succeeded() && pack.primaryAmount == 3 && p.potions == 6,
          "store buys potion pack");
    p.potions = 98;
    auto full = StoreSystem::purchase(p, OfferId::PotionPack);
    check(full.code == ResultCode::InventoryFull && p.potions == 98,
          "store rejects pack that would exceed potion cap");

    p.herbs = 294; p.coins = 200;
    check(StoreSystem::purchase(p, OfferId::HerbBundle).succeeded() && p.herbs == 300,
          "herb bundle reaches capacity exactly");
    const auto herbOverflow = StoreSystem::purchase(p, OfferId::Herbs);
    check(herbOverflow.code == ResultCode::InventoryFull && p.herbs == 300,
          "herb cap blocks overflow");
    p.essence = 997; p.coins = 300;
    check(StoreSystem::purchase(p, OfferId::EssencePack).succeeded() && p.essence == 1000,
          "essence pack reaches capacity exactly");

    p.coins = 1000; p.swordTier = 1;
    check(StoreSystem::price(p, OfferId::BladeUpgrade) == 135, "blade upgrade price scales by rank");
    const int oldDamage = p.damage;
    auto blade = StoreSystem::purchase(p, OfferId::BladeUpgrade);
    check(blade.succeeded() && blade.primaryAmount == 2 && blade.bonusXp == 10,
          "blade upgrade advances rank and reports progression XP");
    check(p.damage == oldDamage + 6, "blade upgrade adds six damage");
    p.swordTier = 5;
    check(StoreSystem::purchase(p, OfferId::BladeUpgrade).code == ResultCode::MaxTier,
          "blade cannot exceed rank five");
    p.swordTier = 0; p.damage = 1000000;
    check(StoreSystem::purchase(p, OfferId::BladeUpgrade).code == ResultCode::InvalidState,
          "blade upgrade guards stat overflow");

    p.armorTier = 0; p.coins = 1000; p.hp = 90; p.maxHp = 100;
    check(StoreSystem::price(p, OfferId::ArmorUpgrade) == 80, "armor initial cost matches V3.60");
    auto armor = StoreSystem::purchase(p, OfferId::ArmorUpgrade);
    check(armor.succeeded() && p.armorTier == 1 && p.maxHp == 112 && p.hp == 102,
          "armor raises max health and restores twelve current health");
    p.armorTier = 4;
    check(StoreSystem::purchase(p, OfferId::ArmorUpgrade).code == ResultCode::MaxTier,
          "armor cannot exceed rank four");
    p.armorTier = 0; p.maxHp = 1000000; p.hp = 1000000;
    check(StoreSystem::purchase(p, OfferId::ArmorUpgrade).code == ResultCode::InvalidState,
          "armor upgrade guards max-health overflow");

    p.coins = 500;
    auto cloak = StoreSystem::purchase(p, OfferId::CrimsonCloak);
    check(cloak.succeeded() && cloak.coinsSpent == 180 &&
          p.ownedAppearances[static_cast<std::size_t>(Appearance::Crimson)] &&
          p.equippedAppearance == Appearance::Crimson, "first cloak purchase unlocks and equips");
    const auto coinsAfterCloak = p.coins;
    auto reEquip = StoreSystem::purchase(p, OfferId::CrimsonCloak);
    check(reEquip.code == ResultCode::AlreadyEquipped && p.coins == coinsAfterCloak,
          "currently equipped cloak cannot charge again");
    p.equippedAppearance = Appearance::Emerald;
    reEquip = StoreSystem::purchase(p, OfferId::CrimsonCloak);
    check(reEquip.code == ResultCode::EquippedExisting && p.coins == coinsAfterCloak &&
          p.equippedAppearance == Appearance::Crimson, "owned cloak re-equips for free");

    p.potions = 2; p.hp = 50; p.maxHp = 100;
    auto potionUse = StoreSystem::usePotion(p);
    check(potionUse.succeeded() && potionUse.primaryAmount == 50 && p.hp == 100 && p.potions == 1,
          "potion restores at most 58 and consumes one");
    p.hp = 100;
    check(StoreSystem::usePotion(p).code == ResultCode::HealthFull && p.potions == 1,
          "potion is preserved when health is full");
    p.herbs = 3; p.potions = 98;
    check(StoreSystem::craftPotion(p).succeeded() && p.herbs == 0 && p.potions == 99,
          "craft potion consumes three herbs");
    check(StoreSystem::craftPotion(p).code == ResultCode::InsufficientResources,
          "craft potion checks herb requirement");
    p.herbs = 3; p.potions = 99;
    check(StoreSystem::craftPotion(p).code == ResultCode::InventoryFull && p.herbs == 3,
          "craft potion refuses inventory overflow without consuming herbs");

    p.herbs = 8; p.trailRations = 0;
    check(StoreSystem::craftTrailRation(p).succeeded() && p.herbs == 4 && p.trailRations == 1,
          "trail ration consumes four herbs");
    p.hp = 50; p.maxHp = 200; p.energy = 12; p.maxEnergy = 100;
    auto ration = StoreSystem::useTrailRation(p);
    check(ration.succeeded() && ration.primaryAmount == 64 && p.hp == 114 &&
          p.energy == 100 && p.trailRations == 0,
          "ration restores 32 percent max health and all energy");
    check(StoreSystem::useTrailRation(p).code == ResultCode::NoConsumable,
          "ration use checks stock");

    p = PlayerEconomy{}; p.coins = 1000; p.essence = 10; p.herbs = 10;
    auto rune1 = StoreSystem::craftRune(p);
    check(rune1.succeeded() && rune1.coinsSpent == 120 && p.runeTier == 1 &&
          p.essence == 8 && p.herbs == 7, "first rune uses reference cost and materials");
    check(StoreSystem::craftRune(p).code == ResultCode::RankRequired,
          "second rune requires veil reputation 180");
    p.veilReputation = 180;
    auto rune2 = StoreSystem::craftRune(p);
    check(rune2.succeeded() && rune2.coinsSpent == 198 && p.runeTier == 2,
          "second rune applies eight percent reputation discount");
    p.veilReputation = 650; p.essence = 100; p.herbs = 100;
    auto rune3 = StoreSystem::craftRune(p);
    check(rune3.succeeded() && p.runeTier == 3, "third rune unlocks at reputation 650");
    check(StoreSystem::craftRune(p).code == ResultCode::MaxTier, "rune crafting stops at tier three");

    p = PlayerEconomy{}; p.coins = 1000; p.essence = 20;
    auto infusion1 = StoreSystem::upgradeInfusion(p);
    check(infusion1.succeeded() && infusion1.coinsSpent == 75 &&
          p.infusionTier == 1 && near(p.criticalChance, 0.085F) && p.damage == 14,
          "first blade infusion applies damage and critical chance");
    p.infusionTier = 3;
    check(StoreSystem::upgradeInfusion(p).code == ResultCode::MaxTier,
          "blade infusion stops at tier three");

    p.coins = -1;
    check(!StoreSystem::isValid(p) && StoreSystem::purchase(p, OfferId::Potion).code == ResultCode::InvalidState,
          "economy rejects corrupted negative currency");
    check(StoreSystem::localizedName(OfferId::Count, Language::Arabic).empty(),
          "invalid offer localization is safely empty");
    check(StoreSystem::localizedName(OfferId::Potion, static_cast<Language>(99)).empty(),
          "invalid language enum is safely rejected");

    PlayerEconomy persisted;
    persisted.coins = 7654; persisted.potions = 8; persisted.herbs = 42;
    persisted.essence = 11; persisted.trailRations = 3; persisted.swordTier = 3;
    persisted.armorTier = 2; persisted.runeTier = 1; persisted.infusionTier = 2;
    persisted.veilReputation = 220; persisted.hp = 77; persisted.maxHp = 124;
    persisted.energy = 33; persisted.maxEnergy = 120; persisted.damage = 34;
    persisted.criticalChance = 0.155F;
    persisted.ownedAppearances[static_cast<std::size_t>(Appearance::Crimson)] = true;
    persisted.equippedAppearance = Appearance::Crimson;
    const std::string saveData = StoreSystem::serializePlayer(persisted);
    const auto loadedData = StoreSystem::deserializePlayer(saveData);
    check(loadedData.has_value(), "economy save snapshot round-trip parses");
    if (loadedData) {
        check(loadedData->coins == 7654 && loadedData->herbs == 42 && loadedData->runeTier == 1,
              "economy save preserves currency, resources and progression ranks");
        check(loadedData->hp == 77 && loadedData->maxHp == 124 && loadedData->damage == 34,
              "economy save preserves character combat values");
        check(loadedData->ownedAppearances[static_cast<std::size_t>(Appearance::Crimson)] &&
              loadedData->equippedAppearance == Appearance::Crimson,
              "economy save preserves owned and equipped cloak state");
    }
    check(!StoreSystem::deserializePlayer("KYREVEX_ECONOMY 2\n"),
          "economy save rejects unsupported schema");
    std::string brokenSave = saveData;
    const auto coinsPos = brokenSave.find("coins 7654");
    if (coinsPos != std::string::npos) brokenSave.replace(coinsPos, 10, "coins -999");
    check(!StoreSystem::deserializePlayer(brokenSave), "economy save rejects corrupted negative coins");
    check(StoreSystem::serializePlayer(PlayerEconomy{.coins = -1}).empty(),
          "economy encoder refuses invalid player state");

    PlayerEconomy uiPlayer;
    uiPlayer.coins = 120;
    const auto arStore = StoreScreenPresenter::build(uiPlayer, Language::Arabic);
    const auto enStore = StoreScreenPresenter::build(uiPlayer, Language::English);
    const auto trStore = StoreScreenPresenter::build(uiPlayer, Language::Turkish);
    check(arStore.valid && arStore.cards.size() == 11 && arStore.coinBalance == 120,
          "store presenter builds complete Arabic store view");
    check(enStore.valid && enStore.cards[0].title == "Healing Potion",
          "store presenter localizes English offer titles");
    check(trStore.valid && trStore.cards[6].title == "Yol Azığı",
          "store presenter localizes Turkish offer titles");
    check(arStore.cards[7].price == 70 && arStore.cards[7].actionLabel == "ترقية السيف",
          "store presenter exposes dynamic blade upgrade button");
    uiPlayer.potions = 99;
    const auto fullStore = StoreScreenPresenter::build(uiPlayer, Language::Arabic);
    check(!fullStore.cards[0].actionEnabled && fullStore.cards[0].actionLabel == "المخزون ممتلئ",
          "store presenter disables capped inventory item");
    uiPlayer.coins = -1;
    check(!StoreScreenPresenter::build(uiPlayer, Language::Arabic).valid,
          "store presenter refuses invalid economy state");

    PlayerEconomy controllerPlayer;
    controllerPlayer.coins = 120;
    StoreController controller(controllerPlayer, Language::Arabic);
    const auto initialRevision = controller.revision();
    check(controller.open().valid && controller.screen().cards.size() == 11,
          "store controller opens with renderer-ready card model");
    auto bought = controller.activate(OfferId::Potion);
    check(bought.result.succeeded() && controllerPlayer.coins == 85 && controllerPlayer.potions == 3,
          "store controller routes touch action through authoritative purchase rules");
    check(bought.screen.coinBalance == 85 && bought.revision > initialRevision,
          "store controller refreshes screen model after purchase");
    check(controller.setLanguage(Language::Turkish) &&
          controller.screen().cards[0].title == "İyileştirme İksiri",
          "store controller refreshes card labels when language changes");
    check(!controller.setLanguage(static_cast<Language>(99)),
          "store controller safely rejects unknown language");
    controllerPlayer.herbs = 3;
    auto crafted = controller.craftPotion();
    check(crafted.result.succeeded() && controllerPlayer.herbs == 0 && controllerPlayer.potions == 4,
          "store controller routes crafting action and refreshes economy state");
    controllerPlayer.swordTier = 0; controllerPlayer.coins = 1000;
    auto upgraded = controller.activate(OfferId::BladeUpgrade);
    check(upgraded.result.succeeded() && upgraded.result.bonusXp == 10 &&
          upgraded.screen.cards[7].price == 135,
          "store controller exposes progression XP and refreshed dynamic prices");
}


void inputRouterTests() {
    using namespace kyrevex::input;
    InputRouter input;

    check(near(input.deadzone(), InputRouter::kDefaultDeadzone),
          "input router starts with the documented radial deadzone");
    check(input.setButton(Source::Keyboard, 26, Action::Attack, true),
          "keyboard attack binding accepts key-down");
    const auto& attackDown = input.advanceFrame();
    check(attackDown.isDown(Action::Attack) && attackDown.wasPressed(Action::Attack),
          "button press produces held and one-frame pressed state");
    const auto& heldAgain = input.advanceFrame();
    check(heldAgain.isDown(Action::Attack) && !heldAgain.wasPressed(Action::Attack),
          "held button does not repeat pressed edge each frame");
    check(input.setButton(Source::Keyboard, 26, Action::Attack, false),
          "keyboard attack binding accepts key-up");
    const auto& attackUp = input.advanceFrame();
    check(!attackUp.isDown(Action::Attack) && attackUp.wasReleased(Action::Attack),
          "button release produces one-frame released state");
    check(input.setButton(Source::Keyboard, 17, Action::Attack, true) &&
          input.setButton(Source::Touch, 1001, Action::Attack, true),
          "keyboard and touch may hold the same action simultaneously");
    (void)input.advanceFrame();
    check(input.setButton(Source::Keyboard, 17, Action::Attack, false),
          "releasing one source leaves the second source registered");
    check(input.advanceFrame().isDown(Action::Attack),
          "action remains held while another source still holds it");
    check(input.setButton(Source::Touch, 1001, Action::Attack, false),
          "touch pointer releases independently from keyboard");
    check(input.advanceFrame().wasReleased(Action::Attack),
          "action releases only after its final source is released");

    check(input.setButton(Source::Keyboard, 30, Action::MoveRight, true) &&
          input.setButton(Source::Keyboard, 31, Action::MoveUp, true),
          "digital movement directions accept simultaneous diagonal input");
    const auto& diagonal = input.advanceFrame();
    check(near(diagonal.moveMagnitude, 1.0F) && near(diagonal.moveX, 0.7071067F, 0.001F) &&
          near(diagonal.moveY, 0.7071067F, 0.001F),
          "digital diagonal movement is normalized to unit magnitude");
    check(input.setButton(Source::Keyboard, 30, Action::MoveRight, false) &&
          input.setButton(Source::Keyboard, 31, Action::MoveUp, false),
          "digital movement keys release cleanly");
    (void)input.advanceFrame();

    check(input.setMoveAxis(Source::Touch, 4, 0.10F, 0.0F),
          "touch joystick axis accepts a valid control id");
    check(near(input.advanceFrame().moveMagnitude, 0.0F),
          "analog movement below radial deadzone is ignored");
    check(input.setMoveAxis(Source::Touch, 4, 1.0F, 0.0F),
          "touch joystick axis updates without allocating another slot");
    check(near(input.advanceFrame().moveX, 1.0F) && near(input.snapshot().moveY, 0.0F),
          "full analog deflection maps to full movement strength");
    check(input.releaseMoveAxis(Source::Touch, 4),
          "touch joystick axis releases by pointer id");
    check(near(input.advanceFrame().moveMagnitude, 0.0F),
          "released touch joystick returns movement to neutral");

    check(input.setMoveAxis(Source::Gamepad, 0, 0.6F, 0.0F) &&
          input.setMoveAxis(Source::Touch, 77, 0.6F, 0.0F),
          "gamepad and touch axes can coexist");
    check(near(input.advanceFrame().moveX, 1.0F),
          "combined movement axes clamp to the unit range");
    input.releaseSource(Source::Gamepad);
    check(near(input.advanceFrame().moveX, (0.6F - InputRouter::kDefaultDeadzone) /
               (1.0F - InputRouter::kDefaultDeadzone), 0.001F),
          "releasing one input source preserves the calibrated movement of the other source");
    input.releaseControl(Source::Touch, 77);
    check(near(input.advanceFrame().moveMagnitude, 0.0F),
          "releasing a control clears its axis state");

    check(input.setButton(Source::Keyboard, 44, Action::Guard, true),
          "guard action accepts initial physical binding");
    (void)input.advanceFrame();
    check(input.setButton(Source::Keyboard, 44, Action::Dash, true),
          "held physical control can be remapped atomically");
    const auto& remapped = input.advanceFrame();
    check(!remapped.isDown(Action::Guard) && remapped.wasReleased(Action::Guard) &&
          remapped.isDown(Action::Dash) && remapped.wasPressed(Action::Dash),
          "remapping a held control releases old action and presses new action");

    input.focusLost();
    const auto& focusReset = input.advanceFrame();
    check(!focusReset.isDown(Action::Dash) && focusReset.wasReleased(Action::Dash),
          "focus loss releases held buttons without stuck input");

    check(input.setButton(Source::Touch, 91, Action::Interact, true),
          "touch interaction button accepts pointer id");
    (void)input.advanceFrame();
    input.releaseSource(Source::Touch);
    check(input.advanceFrame().wasReleased(Action::Interact),
          "source cancellation clears all touch button holds");

    input.setDeadzone(0.50F);
    check(near(input.deadzone(), 0.50F), "custom deadzone is applied");
    input.setDeadzone(4.0F);
    check(near(input.deadzone(), 0.95F), "deadzone clamps to safe upper bound");
    input.setDeadzone(std::numeric_limits<float>::quiet_NaN());
    check(near(input.deadzone(), InputRouter::kDefaultDeadzone),
          "non-finite deadzone falls back to safe default");

    check(input.setMoveAxis(Source::Gamepad, 9,
                            std::numeric_limits<float>::quiet_NaN(),
                            std::numeric_limits<float>::infinity()),
          "axis accepts non-finite device data for safe sanitization");
    const auto& sanitized = input.advanceFrame();
    check(near(sanitized.moveX, 0.0F) && near(sanitized.moveY, 0.0F),
          "non-finite axis values are converted to neutral movement");

    check(!input.setButton(static_cast<Source>(99), 1, Action::Attack, true),
          "invalid input source is rejected");
    check(!input.setButton(Source::Keyboard, 1, static_cast<Action>(99), true),
          "invalid input action is rejected");
    check(!input.setMoveAxis(static_cast<Source>(99), 1, 0.5F, 0.5F),
          "invalid axis source is rejected");
    check(!input.snapshot().isDown(static_cast<Action>(99)) &&
          !input.snapshot().wasPressed(static_cast<Action>(99)) &&
          !input.snapshot().wasReleased(static_cast<Action>(99)),
          "snapshot safely rejects unknown action indexes");

    InputRouter buttonCapacity;
    bool allButtonsAccepted = true;
    for (std::uint32_t id = 0; id < InputRouter::kMaxButtons; ++id) {
        allButtonsAccepted = buttonCapacity.setButton(Source::Touch, id, Action::Attack, true) &&
                             allButtonsAccepted;
    }
    check(allButtonsAccepted, "button table accepts its documented maximum capacity");
    check(!buttonCapacity.setButton(Source::Touch, 999, Action::Attack, true),
          "button table rejects overflow without memory corruption");
    buttonCapacity.releaseSource(Source::Touch);
    check(buttonCapacity.setButton(Source::Touch, 999, Action::Attack, true),
          "released button slots are reusable after source cancellation");

    InputRouter axisCapacity;
    bool allAxesAccepted = true;
    for (std::uint32_t id = 0; id < InputRouter::kMaxMoveAxes; ++id) {
        allAxesAccepted = axisCapacity.setMoveAxis(Source::Gamepad, id, 0.1F, 0.0F) &&
                          allAxesAccepted;
    }
    check(allAxesAccepted, "axis table accepts its documented maximum capacity");
    check(!axisCapacity.setMoveAxis(Source::Gamepad, 999, 0.5F, 0.0F),
          "axis table rejects overflow without memory corruption");
    axisCapacity.focusLost();
    check(axisCapacity.setMoveAxis(Source::Gamepad, 999, 0.5F, 0.0F),
          "focus reset makes analog axis slots reusable");
}


void inputBindingsTests() {
    using namespace kyrevex::input;
    auto bindings = InputBindings::defaults();
    check(bindings.size() == 16, "default keyboard map contains all sixteen core actions");
    check(bindings.actionFor(Source::Keyboard, static_cast<std::uint32_t>(HidKey::W)) == Action::MoveUp,
          "default HID W key maps to forward movement");
    check(bindings.actionFor(Source::Keyboard, static_cast<std::uint32_t>(HidKey::Space)) == Action::Attack,
          "default Space key maps to basic attack");
    check(bindings.actionFor(Source::Keyboard, static_cast<std::uint32_t>(HidKey::LeftShift)) == Action::Dash,
          "default left Shift key maps to dash");
    check(!bindings.actionFor(Source::Gamepad, 0).has_value(),
          "unconfigured gamepad controls are not assigned implicitly");

    const auto wKey = static_cast<std::uint32_t>(HidKey::W);
    check(bindings.bind(Source::Keyboard, wKey, Action::Sprint),
          "existing keyboard control can be remapped");
    check(bindings.size() == 16 && bindings.actionFor(Source::Keyboard, wKey) == Action::Sprint,
          "remapping replaces the previous action without duplicating the physical key");
    check(bindings.bind(Source::Gamepad, 0, Action::Attack),
          "one action can be assigned to a second physical device");
    check(bindings.size() == 17 && bindings.actionFor(Source::Gamepad, 0) == Action::Attack,
          "keyboard and gamepad can independently map to the same action");
    check(bindings.bind(Source::Touch, 500, Action::Interact),
          "touch source supports stable UI action identifiers");
    check(bindings.unbind(Source::Touch, 500) && bindings.size() == 17,
          "touch binding can be removed without changing other devices");
    check(!bindings.unbind(Source::Touch, 500),
          "removing an unknown binding reports no change");

    const std::string saved = bindings.serialize();
    const auto restored = InputBindings::deserialize(saved);
    check(restored.has_value(), "input binding settings round-trip parses");
    if (restored) {
        check(restored->size() == bindings.size(),
              "input binding round-trip preserves entry count");
        check(restored->actionFor(Source::Keyboard, wKey) == Action::Sprint &&
              restored->actionFor(Source::Gamepad, 0) == Action::Attack,
              "input binding round-trip preserves remapped multi-device controls");
    }

    check(!InputBindings::deserialize("NOT_KYREVEX 1\ncount 0\n"),
          "input bindings reject unknown file signature");
    check(!InputBindings::deserialize("KYREVEX_INPUT_BINDINGS 2\ncount 0\n"),
          "input bindings reject unsupported future schema");
    check(!InputBindings::deserialize("KYREVEX_INPUT_BINDINGS 1\ncount 65\n"),
          "input bindings reject a count above fixed storage capacity");
    check(!InputBindings::deserialize("KYREVEX_INPUT_BINDINGS 1\ncount 1\nbinding 99 4 2\n"),
          "input bindings reject invalid source enum values");
    check(!InputBindings::deserialize("KYREVEX_INPUT_BINDINGS 1\ncount 1\nbinding 0 4 99\n"),
          "input bindings reject invalid action enum values");
    check(!InputBindings::deserialize(
              "KYREVEX_INPUT_BINDINGS 1\ncount 2\nbinding 0 4 1\nbinding 0 4 2\n"),
          "input bindings reject duplicate physical controls in persisted data");
    check(!InputBindings::deserialize("KYREVEX_INPUT_BINDINGS 1\ncount 0\nextra\n"),
          "input bindings reject trailing unrecognized data");

    check(!bindings.bind(static_cast<Source>(99), 1, Action::Attack),
          "input bindings reject invalid source when remapping");
    check(!bindings.bind(Source::Keyboard, 1, static_cast<Action>(99)),
          "input bindings reject invalid action when remapping");
    check(!bindings.actionFor(static_cast<Source>(99), 1).has_value(),
          "input binding lookup rejects invalid source");

    InputBindings capacity;
    bool allAccepted = true;
    for (std::uint32_t i = 0; i < InputBindings::kMaxBindings; ++i) {
        allAccepted = capacity.bind(Source::Gamepad, i, Action::Attack) && allAccepted;
    }
    check(allAccepted && capacity.size() == InputBindings::kMaxBindings,
          "input binding map accepts its documented maximum capacity");
    check(!capacity.bind(Source::Gamepad, 999, Action::Attack),
          "input binding map rejects overflow without altering the map");
    check(capacity.unbind(Source::Gamepad, 10) &&
          capacity.bind(Source::Gamepad, 999, Action::Attack),
          "unbound input map slots can be reused safely");
}


void touchControlLayoutTests() {
    using namespace kyrevex::input;
    auto layout = TouchControlLayout::defaults();
    check(layout.controls().size() == kTouchControlCount && kTouchControlCount == 12,
          "default touch layout contains all twelve core controls");
    const auto* stick = layout.get(TouchControlId::MovementStick);
    const auto* attack = layout.get(TouchControlId::Attack);
    check(stick != nullptr && attack != nullptr && stick->x < 0.5F && attack->x > 0.5F,
          "default landscape layout places movement left and combat controls right");
    check(stick != nullptr && stick->size > attack->size,
          "movement stick starts larger than individual action buttons");
    check(layout.get(static_cast<TouchControlId>(99)) == nullptr,
          "layout safely rejects invalid control identifiers");

    check(layout.setPosition(TouchControlId::Attack, 0.2F, 0.3F),
          "touch button accepts custom normalized position");
    const auto* moved = layout.get(TouchControlId::Attack);
    check(moved != nullptr && near(moved->x, 0.2F) && near(moved->y, 0.3F),
          "custom position is stored in normalized viewport coordinates");
    check(layout.setPosition(TouchControlId::Attack, -5.0F, 4.0F),
          "finite out-of-screen position is safely constrained");
    moved = layout.get(TouchControlId::Attack);
    check(moved != nullptr && moved->x >= moved->size * 0.5F &&
          moved->x <= 1.0F - moved->size * 0.5F && moved->y >= moved->size * 0.5F &&
          moved->y <= 1.0F - moved->size * 0.5F,
          "button center remains inside viewport after position constraint");
    check(!layout.setPosition(TouchControlId::Attack,
                              std::numeric_limits<float>::quiet_NaN(), 0.5F),
          "non-finite custom position is rejected");

    check(layout.setSize(TouchControlId::Attack, 0.25F),
          "touch button accepts custom size");
    moved = layout.get(TouchControlId::Attack);
    check(moved != nullptr && near(moved->size, 0.25F),
          "custom button size is retained");
    check(layout.setSize(TouchControlId::Attack, 2.0F),
          "oversized control request is clamped rather than overflowing viewport");
    moved = layout.get(TouchControlId::Attack);
    check(moved != nullptr && near(moved->size, TouchControlLayout::kMaxSize),
          "control size is clamped to documented maximum");
    check(layout.setSize(TouchControlId::Attack, 0.001F),
          "undersized control request is clamped to a usable minimum");
    moved = layout.get(TouchControlId::Attack);
    check(moved != nullptr && near(moved->size, TouchControlLayout::kMinSize),
          "control size is clamped to documented minimum");
    check(!layout.setSize(TouchControlId::Attack,
                          std::numeric_limits<float>::infinity()),
          "non-finite control size is rejected");

    check(layout.setOpacity(TouchControlId::Guard, 0.35F),
          "touch control accepts custom opacity");
    const auto* guard = layout.get(TouchControlId::Guard);
    check(guard != nullptr && near(guard->opacity, 0.35F),
          "custom opacity is stored independently");
    check(layout.setOpacity(TouchControlId::Guard, 3.0F),
          "opacity values above one are clamped");
    guard = layout.get(TouchControlId::Guard);
    check(guard != nullptr && near(guard->opacity, 1.0F),
          "opacity clamps to full visibility");
    check(layout.setOpacity(TouchControlId::Guard, -1.0F),
          "negative opacity is clamped");
    guard = layout.get(TouchControlId::Guard);
    check(guard != nullptr && near(guard->opacity, 0.0F),
          "zero opacity permits fully transparent controls");
    check(!layout.setOpacity(TouchControlId::Guard,
                             std::numeric_limits<float>::quiet_NaN()),
          "non-finite opacity is rejected");

    check(layout.setVisible(TouchControlId::Sprint, false),
          "optional touch control can be hidden");
    const auto* sprint = layout.get(TouchControlId::Sprint);
    check(sprint != nullptr && !sprint->visible,
          "hidden state is exposed to renderer model");
    check(layout.setVisible(TouchControlId::Sprint, true),
          "hidden touch control can be restored");

    const auto originalX = layout.get(TouchControlId::MovementStick)->x;
    layout.setLeftHanded(true);
    check(layout.isLeftHanded() &&
          near(layout.get(TouchControlId::MovementStick)->x, 1.0F - originalX),
          "left-handed mode mirrors normalized control positions");
    const auto mirroredX = layout.get(TouchControlId::Attack)->x;
    layout.setLeftHanded(true);
    check(near(layout.get(TouchControlId::Attack)->x, mirroredX),
          "reapplying current handedness does not mirror positions twice");
    layout.setLeftHanded(false);
    check(!layout.isLeftHanded() &&
          near(layout.get(TouchControlId::MovementStick)->x, originalX),
          "restoring right-handed mode reverses the mirrored layout");

    const std::string saved = layout.serialize();
    const auto restored = TouchControlLayout::deserialize(saved);
    check(restored.has_value(), "touch layout save round-trip parses");
    if (restored) {
        check(!restored->isLeftHanded() && restored->get(TouchControlId::Sprint)->visible,
              "touch layout save preserves handedness and visibility settings");
        check(near(restored->get(TouchControlId::Attack)->size,
                   layout.get(TouchControlId::Attack)->size) &&
              near(restored->get(TouchControlId::Guard)->opacity,
                   layout.get(TouchControlId::Guard)->opacity),
              "touch layout save preserves size and opacity values");
    }
    check(!TouchControlLayout::deserialize("BAD_LAYOUT 1\n"),
          "touch layout rejects unknown file signature");
    check(!TouchControlLayout::deserialize("KYREVEX_TOUCH_LAYOUT 2\n"),
          "touch layout rejects unsupported schema version");
    check(!TouchControlLayout::deserialize(
              "KYREVEX_TOUCH_LAYOUT 1\nleft_handed 2\ncount 12\n"),
          "touch layout rejects invalid handedness state");
    check(!TouchControlLayout::deserialize(
              "KYREVEX_TOUCH_LAYOUT 1\nleft_handed 0\ncount 11\n"),
          "touch layout rejects incomplete control arrays");
    check(!TouchControlLayout::deserialize(saved + "unexpected\n"),
          "touch layout rejects trailing unrecognized data");

    std::string invalidSize = saved;
    const auto sizePos = invalidSize.find("control 0 ");
    if (sizePos != std::string::npos) {
        const auto lineEnd = invalidSize.find('\n', sizePos);
        invalidSize.replace(sizePos, lineEnd - sizePos, "control 0 0.15 0.77 0.50 0.80 1");
    }
    check(!TouchControlLayout::deserialize(invalidSize),
          "touch layout rejects persisted size values outside safe range");

    std::string duplicateId = saved;
    const auto firstLine = duplicateId.find("control 0 ");
    const auto secondLine = duplicateId.find("control 1 ");
    if (firstLine != std::string::npos && secondLine != std::string::npos) {
        duplicateId.replace(secondLine, 9, "control 0");
    }
    check(!TouchControlLayout::deserialize(duplicateId),
          "touch layout rejects duplicated control identifiers");
}

} // namespace

int main() {
    audioTests();
    audioEngineTests();
    builtinAudioTests();
    storeTests();
    inputRouterTests();
    inputBindingsTests();
    touchControlLayoutTests();
    std::cout << "Checks: " << checks << "\nFailures: " << failures << '\n';
    return failures == 0 ? EXIT_SUCCESS : EXIT_FAILURE;
}
