#pragma once

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct AAudioStream AAudioStream;
typedef struct AAudioStreamBuilder AAudioStreamBuilder;
typedef int32_t aaudio_result_t;
typedef int32_t aaudio_stream_state_t;
typedef int32_t aaudio_data_callback_result_t;
typedef int32_t aaudio_direction_t;
typedef int32_t aaudio_format_t;
typedef int32_t aaudio_performance_mode_t;
typedef int32_t aaudio_sharing_mode_t;
typedef int32_t aaudio_usage_t;
typedef int32_t aaudio_content_type_t;

enum {
    AAUDIO_OK = 0,
    AAUDIO_ERROR_INVALID_FORMAT = -899,
    AAUDIO_DIRECTION_OUTPUT = 0,
    AAUDIO_FORMAT_PCM_FLOAT = 2,
    AAUDIO_PERFORMANCE_MODE_LOW_LATENCY = 12,
    AAUDIO_SHARING_MODE_SHARED = 1,
    AAUDIO_USAGE_GAME = 14,
    AAUDIO_CONTENT_TYPE_MUSIC = 2,
    AAUDIO_CALLBACK_RESULT_STOP = 0,
    AAUDIO_CALLBACK_RESULT_CONTINUE = 1,
    AAUDIO_STREAM_STATE_STARTED = 6,
    AAUDIO_STREAM_STATE_STARTING = 3,
    AAUDIO_STREAM_STATE_PAUSING = 7,
    AAUDIO_STREAM_STATE_PAUSED = 8
};

typedef aaudio_data_callback_result_t (*AAudioStream_dataCallback)(AAudioStream*, void*, void*, int32_t);
typedef void (*AAudioStream_errorCallback)(AAudioStream*, void*, aaudio_result_t);

aaudio_result_t AAudio_createStreamBuilder(AAudioStreamBuilder** builder);
void AAudioStreamBuilder_delete(AAudioStreamBuilder* builder);
void AAudioStreamBuilder_setDirection(AAudioStreamBuilder*, aaudio_direction_t);
void AAudioStreamBuilder_setFormat(AAudioStreamBuilder*, aaudio_format_t);
void AAudioStreamBuilder_setChannelCount(AAudioStreamBuilder*, int32_t);
void AAudioStreamBuilder_setPerformanceMode(AAudioStreamBuilder*, aaudio_performance_mode_t);
void AAudioStreamBuilder_setSharingMode(AAudioStreamBuilder*, aaudio_sharing_mode_t);
void AAudioStreamBuilder_setUsage(AAudioStreamBuilder*, aaudio_usage_t);
void AAudioStreamBuilder_setContentType(AAudioStreamBuilder*, aaudio_content_type_t);
void AAudioStreamBuilder_setSampleRate(AAudioStreamBuilder*, int32_t);
void AAudioStreamBuilder_setDataCallback(AAudioStreamBuilder*, AAudioStream_dataCallback, void*);
void AAudioStreamBuilder_setErrorCallback(AAudioStreamBuilder*, AAudioStream_errorCallback, void*);
aaudio_result_t AAudioStreamBuilder_openStream(AAudioStreamBuilder*, AAudioStream**);
int32_t AAudioStream_getSampleRate(AAudioStream*);
int32_t AAudioStream_getChannelCount(AAudioStream*);
aaudio_stream_state_t AAudioStream_getState(AAudioStream*);
aaudio_result_t AAudioStream_requestStart(AAudioStream*);
aaudio_result_t AAudioStream_requestStop(AAudioStream*);
aaudio_result_t AAudioStream_close(AAudioStream*);

#ifdef __cplusplus
}
#endif
