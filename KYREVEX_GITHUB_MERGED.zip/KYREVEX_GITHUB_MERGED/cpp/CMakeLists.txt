cmake_minimum_required(VERSION 3.20)
project(KYREVEX_CPP_CONTINUATION VERSION 0.3.0 LANGUAGES CXX)

option(KYREVEX_BUILD_TESTS "Build native unit tests" ON)
option(KYREVEX_BUILD_AUDIO_PREVIEW "Build the original procedural audio preview tool" OFF)

add_library(kyrevex_continuation STATIC
    src/game/AudioSettings.cpp
    src/game/AudioEngine.cpp
    src/game/BuiltinAudioAssets.cpp
    src/game/StoreSystem.cpp
    src/game/StoreScreenModel.cpp
    src/game/StoreController.cpp
    src/game/InputRouter.cpp
    src/game/InputBindings.cpp
    src/game/TouchControlLayout.cpp
)
target_include_directories(kyrevex_continuation PUBLIC ${CMAKE_CURRENT_SOURCE_DIR}/src)
target_compile_features(kyrevex_continuation PUBLIC cxx_std_20)

if(MSVC)
    target_compile_options(kyrevex_continuation PRIVATE /W4 /permissive-)
else()
    target_compile_options(kyrevex_continuation PRIVATE -Wall -Wextra -Wpedantic -Wconversion -Wshadow)
endif()

if(ANDROID)
    target_sources(kyrevex_continuation PRIVATE src/platform/android/AAudioBackend.cpp)
    target_link_libraries(kyrevex_continuation PUBLIC aaudio)
endif()

if(KYREVEX_BUILD_TESTS)
    enable_testing()
    if(NOT ANDROID)
        # Compile-check the Android AAudio adapter against a minimal API-shape
        # stub when an Android NDK is not installed on the host.
        add_library(kyrevex_aaudio_api_shape OBJECT src/platform/android/AAudioBackend.cpp)
        target_include_directories(kyrevex_aaudio_api_shape PRIVATE
            ${CMAKE_CURRENT_SOURCE_DIR}/src
            ${CMAKE_CURRENT_SOURCE_DIR}/tests/android_stubs
        )
        target_compile_definitions(kyrevex_aaudio_api_shape PRIVATE __ANDROID__)
        target_compile_features(kyrevex_aaudio_api_shape PRIVATE cxx_std_20)
        if(NOT MSVC)
            target_compile_options(kyrevex_aaudio_api_shape PRIVATE -Wall -Wextra -Wpedantic -Wconversion -Wshadow)
        endif()
    endif()
    add_executable(kyrevex_module_tests tests/module_tests.cpp)
    target_link_libraries(kyrevex_module_tests PRIVATE kyrevex_continuation)
    target_compile_features(kyrevex_module_tests PRIVATE cxx_std_20)
    add_test(NAME kyrevex_module_tests COMMAND kyrevex_module_tests)
endif()

if(KYREVEX_BUILD_AUDIO_PREVIEW)
    add_executable(kyrevex_audio_preview tools/render_audio_preview.cpp)
    target_link_libraries(kyrevex_audio_preview PRIVATE kyrevex_continuation)
    target_compile_features(kyrevex_audio_preview PRIVATE cxx_std_20)
endif()
