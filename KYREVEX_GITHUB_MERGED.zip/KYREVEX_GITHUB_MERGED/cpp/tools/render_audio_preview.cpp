#include "game/AudioEngine.hpp"
#include "game/AudioSettings.hpp"
#include "game/BuiltinAudioAssets.hpp"

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <string>
#include <vector>

namespace {
void write16(std::ofstream& out, std::uint16_t value) {
    const std::array<char, 2> b{static_cast<char>(value & 0xffU),
                                static_cast<char>((value >> 8U) & 0xffU)};
    out.write(b.data(), static_cast<std::streamsize>(b.size()));
}
void write32(std::ofstream& out, std::uint32_t value) {
    const std::array<char, 4> b{static_cast<char>(value & 0xffU),
                                static_cast<char>((value >> 8U) & 0xffU),
                                static_cast<char>((value >> 16U) & 0xffU),
                                static_cast<char>((value >> 24U) & 0xffU)};
    out.write(b.data(), static_cast<std::streamsize>(b.size()));
}
}

int main(int argc, char** argv) {
    const std::string path = argc > 1 ? argv[1] : "KYREVEX_AUDIO_PREVIEW.wav";
    constexpr std::uint32_t sampleRate = 48000;
    constexpr std::uint32_t seconds = 14;
    constexpr std::uint16_t channels = 2;
    constexpr std::uint16_t bits = 16;
    constexpr std::size_t blockFrames = 480; // 10 ms; event timestamps align to block boundaries
    const std::uint32_t dataBytes = sampleRate * seconds * channels * (bits / 8U);

    kyrevex::audio::AudioEngine engine;
    if (!kyrevex::audio::BuiltinAudioAssets::install(engine,
            kyrevex::audio::BuiltinAudioConfig{sampleRate, 22050, 12})) {
        std::cerr << "Could not install procedural audio assets\n";
        return 1;
    }
    engine.setOutputSampleRate(sampleRate);
    kyrevex::audio::AudioSettings settings;
    settings.setMaster(0.84F);
    settings.apply(engine, {}, 0.0F);
    if (!kyrevex::audio::BuiltinAudioAssets::startBackgroundLoops(engine)) {
        std::cerr << "Could not start background loops\n";
        return 1;
    }

    std::ofstream out(path, std::ios::binary);
    if (!out) {
        std::cerr << "Cannot open output file: " << path << '\n';
        return 1;
    }
    out.write("RIFF", 4); write32(out, 36U + dataBytes); out.write("WAVE", 4);
    out.write("fmt ", 4); write32(out, 16); write16(out, 1); write16(out, channels);
    write32(out, sampleRate); write32(out, sampleRate * channels * (bits / 8U));
    write16(out, channels * (bits / 8U)); write16(out, bits);
    out.write("data", 4); write32(out, dataBytes);

    std::array<float, blockFrames * channels> pcm{};
    std::uint32_t frame = 0;
    while (frame < sampleRate * seconds) {
        if (frame == sampleRate * 1U) {
            (void)kyrevex::audio::BuiltinAudioAssets::play(engine,
                kyrevex::audio::BuiltinClip::UiConfirm, 0.85F);
        } else if (frame == sampleRate * 4U) {
            (void)kyrevex::audio::BuiltinAudioAssets::play(engine,
                kyrevex::audio::BuiltinClip::SwordSlash, 0.90F);
        } else if (frame == sampleRate * 7U) {
            (void)kyrevex::audio::BuiltinAudioAssets::play(engine,
                kyrevex::audio::BuiltinClip::AetherCast, 0.90F);
        } else if (frame == sampleRate * 10U) {
            (void)kyrevex::audio::BuiltinAudioAssets::play(engine,
                kyrevex::audio::BuiltinClip::PlayerHit, 0.90F);
        }
        const std::size_t count = std::min<std::size_t>(blockFrames,
            static_cast<std::size_t>(sampleRate * seconds - frame));
        engine.render(pcm.data(), count, channels);
        for (std::size_t i = 0; i < count * channels; ++i) {
            const float sample = std::clamp(pcm[i], -1.0F, 1.0F);
            const auto value = static_cast<std::int16_t>(std::lrint(sample * 32767.0F));
            write16(out, static_cast<std::uint16_t>(value));
        }
        frame += static_cast<std::uint32_t>(count);
    }
    out.close();
    if (!out) {
        std::cerr << "Failed while writing preview WAV\n";
        return 1;
    }
    std::cout << "Wrote " << path << " (" << seconds << " seconds, "
              << sampleRate << " Hz, stereo PCM16)\n";
    return 0;
}
